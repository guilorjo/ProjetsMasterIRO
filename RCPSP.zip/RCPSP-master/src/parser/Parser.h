#ifndef _PARSER_H_
#define _PARSER_H_

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <regex>
#include <iterator>

class Parser{
private:
	std::ifstream istream;
	int nb_line;



public:
	Parser(std::string filename);
	~Parser();
	bool getData(std::vector<int>& line, char delimiter);
	void skipLines(int nb_lines);
	int getParam();
	void getData(std::vector<int>& line);

};
#endif