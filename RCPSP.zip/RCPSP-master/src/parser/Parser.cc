#include "Parser.h"

Parser::Parser(std::string filename){
	this->istream.open(filename.c_str(), std::ios::in);
	this->nb_line = 0;
	if(!this->istream.is_open()){
		std::cerr << "File cannot be opened" << std::endl;
		exit(1);
	}
}

Parser::~Parser(){
	if(this->istream.is_open()){
		this->istream.close();
	}
}

int Parser::getParam(){
	std::regex l("^[-A-Za-z :.()/]+([0-9]+)[a-zA-Z\\s]*");
	std::string data;
	std::string result;
	if(std::getline(this->istream, data)){
		std::regex_replace(std::back_inserter(result), data.begin(), data.end(),l,"$1");
	}
	return atoi(result.c_str());
}

void Parser::getData(std::vector<int>& line){
	line.clear();
	std::regex l("[\\s]+([\\d]+)");
	std::smatch m;
	std::string data;

	if(std::getline(this->istream, data)){
		while(std::regex_search(data,m,l)){
			std::string d = m[1];
			line.push_back(atoi(d.c_str()));
    		data = m.suffix().str();
		}
	}
}

void Parser::skipLines(int nb_lines){
	int line = 0;
	std::string data;

	while(line < nb_lines){
		std::getline(this->istream, data);
		line++;
	}
}

