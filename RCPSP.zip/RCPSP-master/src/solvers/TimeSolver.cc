/*
 * TimeSolver.cc
 *
 *  Created on: 5 déc. 2015
 *      Author: agallastegui
 */
#include "TimeSolver.h"

TimeSolver::TimeSolver(RCPSPInstance* problem):Solver(problem){
	this->initModel();
}

TimeSolver::~TimeSolver(){}


void TimeSolver::initModel(){
	IloInt nb_jobs = this->problem->nbJobs();
	IloInt nb_ressources = this->problem->nbRessources();
	IloInt T = this->upperBound+1;

	// INITIALISATION DES VARIABLES
	// ----------------------------

	// Variable x_ij : 1 la tâche j succede i. 0 sinon
	IloArray< IloNumVarArray > y(*this->environment, nb_jobs);
	for(IloInt i=0; i<nb_jobs; i++){
		y[i] = IloNumVarArray(*this->environment,T, 0, 1, ILOBOOL);
	}

	// FONCTION OBJECTIF
	// ------------------------------
	// On minimise la date a laquelle on peut ordonnacer la derniere tache (tâche fictive de durée 0).
	IloExpr objectif(*this->environment);
	for(IloInt t=this->earliestStart(nb_jobs-1); t <= this->latestStart(nb_jobs-1); t++){
		objectif += t*y[nb_jobs-1][t];
	}
	this->model->add(IloMinimize(*this->environment, objectif));

	//CONTRAINTES
	//--------------------------------

	//Contrainte 1
	//une tache demarre a un et un seul pas de temps
	for(IloInt i=0; i<nb_jobs;i++){
		IloExpr ctr1(*this->environment);
		for(IloInt t=this->earliestStart(i); t <= this->latestStart(i); t++){
			ctr1 += y[i][t];
		}
		this->model->add(ctr1 == 1);
	}

	//Contrainte 2
	//contraintes de précédences
	for(IloInt i=0; i<nb_jobs; i++){
		for(IloInt j=0; j<nb_jobs; j++){
			if(this->problem->isSuccessor(i,j)==1){
				IloExpr ctr2(*this->environment);
				for(IloInt t=this->earliestStart(j); t <= this->latestStart(j); t++){
					ctr2 += t*y[j][t];
				}
				IloExpr ctr2bis(*this->environment);
				for(IloInt t=this->earliestStart(i); t <= this->latestStart(i); t++){
					ctr2bis += t*y[i][t];
				}
				this->model->add(ctr2 >= ctr2bis + this->problem->jobDuration(i));
			}
		}
	}

	//Contrainte 3
	//contraintes de capacité des machines pour chaque pas de temps
	for(int k=0; k<nb_ressources; k++){
		for(int t=0; t<T; t++){
			IloExpr ctr3(*this->environment);
			for(int i=0; i<nb_jobs; i++){
				IloExpr tmp(*this->environment);
				for(int r=std::max(this->earliestStart(i),t-this->problem->jobDuration(i)+1); r<=std::min(this->latestStart(i),t); r++){
					if(r>=0) tmp += y[i][r];
				}
				ctr3 += tmp*this->problem->consoRessource(i,k);
			}
			this->model->add(ctr3 <= this->problem->capacity(k));
		}
	}
}
