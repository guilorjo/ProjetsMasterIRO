#ifndef _FLOWSOLVER_H_
#define _FLOWSOLVER_H_

#include <iostream>
#include <cstdlib>
#include "Solver.h"

class FlowSolver : public Solver {
public:
	FlowSolver(RCPSPInstance* problem);
	~FlowSolver();
	void initModel();
};
#endif