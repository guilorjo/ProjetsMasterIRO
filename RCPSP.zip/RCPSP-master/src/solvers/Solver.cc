#include "Solver.h"

Solver::Solver(RCPSPInstance* problem){
	this->environment = new IloEnv();
	this->model = new IloModel(*this->environment);
	this->problem = problem;
	//this->upperBound = this->problem->sumDuration();
	this->computeUpperBound();
	this->computePreprocessing();
}

Solver::~Solver(){
	this->environment->end();
}

void Solver::solve(){
	IloCplex cplex(*this->model);

	//cplex.setParam(IloCplex::MIPInterval, 1000);
	//cplex.setParam(IloCplex::MIPSearch, IloCplex::Traditional);

	// cplex.setOut(this->environment->getNullStream());

	cplex.solve();


	// cplex.exportModel("solver.lp");
	// cplex.exportModel("solver.sav");

	IloAlgorithm::Status algo_status = cplex.getStatus();
	if( algo_status != IloAlgorithm::Optimal ){
		this->environment->out() << "Il y a un problème" << std::endl;
	} else {
		this->environment->out() << "Le modèle a été résolu à l'optimal" << std::endl;
		this->environment->out() << "obj.value:  "<< cplex.getObjValue() << std::endl;
	}
}

void Solver::computePreprocessing(){
	// initialize b
	for (int i = 0; i < this->problem->nbJobs(); ++i) {
		std::vector<int> btmp(this->problem->nbJobs());
		this->b.push_back(btmp);
		for (int j = 0; j < this->problem->nbJobs(); ++j) {
			if (i==j) {
				this->b[i][j] = 0;
			} else if (this->problem->isSuccessor(i,j)) {
				this->b[i][j] = this->problem->jobDuration(i);
			} else {
				this->b[i][j] = -(this->upperBound);
			}
		}
	}

	// transitive closure
	for (int j = 0; j < this->problem->nbJobs(); ++j) {
		for (int i = 0; i < this->problem->nbJobs(); ++i) {
			for (int t = 0; t < this->problem->nbJobs(); ++t) {
				this->b[i][t] = std::max(this->b[i][t], this->b[i][j]+this->b[j][t]);
			}
		}
	}

	// draw matrix
	//std::cout << "SSD-matrix :" << std::endl;
	//for (int j = 0; j < this->problem->nbJobs(); ++j) {
	//	for (int i = 0; i < this->problem->nbJobs(); ++i) {
	//		std::cout << std::setw(3) << this->b[j][i] << "|";
	//	}
	//	std::cout << std::endl;
	//}
}

int Solver::earliestStart(int i){
	//return 0; // for testing purpose only
	return this->b[0][i];
}

int Solver::latestStart(int i){
	//return this->upperBound; // for testing purpose only
	return -(this->b[i][0]);
}

int Solver::bigM(int i, int j){
	//return this->upperBound; // for testing purpose only
	return -(this->b[i][j]);
}

// Algorithme de liste en série
// (fonctionne sous supposition que l'ordre des activités est en ordre topologique)
void Solver::computeUpperBound() {
	// init
	std::vector<int> beginTask(this->problem->nbJobs(), 0);
	std::vector<int> canBeginTask(this->problem->nbJobs(), 0);
	int horizon = this->problem->sumDuration()+1;
	matrix resourceMachineTime;
	for (int i = 0; i < this->problem->nbRessources(); i++) {
		std::vector<int> tmp(horizon, 0);
		resourceMachineTime.push_back(tmp);
	}

	// pour chaque tache de la liste
	for (int task = 0; task < this->problem->nbJobs(); task++) {
		// pour chaque temps t à partir de la date au plus tot
		int t = canBeginTask[task];
		bool isPlaced = false;
		while(t < horizon && !isPlaced) {
			isPlaced = true;
			// pour chaque machine et chaque temps de la duree de task
			for(int ttmp = this->problem->jobDuration(task)-1; ttmp >= 0; ttmp--) {
				for (int k = 0; k < this->problem->nbRessources(); k++) {
					// si on depasse la capacite a ce temps, on regarde le prochain temps
					if (resourceMachineTime[k][t+ttmp] + this->problem->consoRessource(task, k) > this->problem->capacity(k)) {
						t += ttmp+1;
						isPlaced = false;
						break;
					}
				}
				if (!isPlaced) {
					break;
				}
			}
		}
		// on peut placer la tache
		beginTask[task] = t;
		// mise à jour des données		
		for (int ttmp = 0; ttmp < this->problem->jobDuration(task); ttmp++) {
			for (int k = 0; k < this->problem->nbRessources(); k++) {
				resourceMachineTime[k][t+ttmp] += this->problem->consoRessource(task, k);
			}
		}
		for (int j = 0; j < this->problem->nbJobs(); j++) {
			if (this->problem->isSuccessor(task,j)) {
				canBeginTask[j] = std::max(canBeginTask[j], beginTask[task]+this->problem->jobDuration(task));
			}
		}
	}
	this->upperBound = beginTask[this->problem->nbJobs()-1];

	// for (int i = 0; i < this->problem->nbJobs(); ++i) {
	// 	std::cout << beginTask[i] << std::endl;
	// }

	std::cout << "Valeur de la solution heuristique : " << this->upperBound << std::endl;
}
