#ifndef _FORBIDDENCONFSOLVER_H_
#define _FORBIDDENCONFSOLVER_H_

#include <utility>
#include <numeric>
#include <ilcplex/ilocplex.h>
#include "Solver.h"

class ForbiddenConfSolver : public Solver {
private:
	IloArray< IloNumVarArray > x;
	IloNumVarArray S;

public:
	ForbiddenConfSolver(RCPSPInstance* problem);
	~ForbiddenConfSolver();
	void initModel();
	void solve();
};
#endif