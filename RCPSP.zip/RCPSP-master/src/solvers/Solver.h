#ifndef _SOLVER_H_
#define _SOLVER_H_

#include <algorithm>
#include <climits>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
#include "ilconcert/iloenv.h"
#include "ilconcert/ilomodel.h"
#include "ilcplex/ilocplexi.h"
#include "ilconcert/ilosys.h"
#include "ilconcert/iloexpression.h"
#include "../problem/RCPSPInstance.h"

class Solver {
protected:
	IloEnv* environment;
	IloModel* model;
	RCPSPInstance* problem;
	matrix b; //start-start distance (SSD)-matrix
	int upperBound;

public:
	Solver(RCPSPInstance* problem);
	virtual ~Solver();
	virtual void initModel() = 0;
	virtual void solve();

	void computePreprocessing();
	int earliestStart(int i);
	int latestStart(int i);
	int bigM(int i, int j);
	void computeUpperBound();
};
#endif