#include "FlowSolver.h"

FlowSolver::FlowSolver(RCPSPInstance* problem):Solver(problem){
	this->initModel();
}

FlowSolver::~FlowSolver(){}

void FlowSolver::initModel(){
	IloInt nb_jobs = this->problem->nbJobs();
	IloInt nb_ressources = this->problem->nbRessources();
	int maxCapacity = 0;
	for (int i = 0; i < this->problem->nbRessources(); ++i){
		maxCapacity = std::max(maxCapacity, this->problem->capacity(i));
	}

	// INITIALISATION DES VARIABLES
	// ----------------------------

	// Variable x_ij : 1 la tâche j succede i. 0 sinon
	IloArray< IloNumVarArray > x(*this->environment, nb_jobs);
	for(IloInt i=0; i<nb_jobs; i++){
		x[i] = IloNumVarArray(*this->environment, nb_jobs, 0, 1, ILOINT);
	}

	// Variable S_i : date de début de la tache i
	IloNumVarArray S(*this->environment, nb_jobs, 0, IloInfinity, ILOINT);

	// Variable f_ijk  ij job & k ressource:
	IloArray< IloArray < IloNumVarArray > > f(*this->environment, nb_jobs);
	for(IloInt i=0; i<nb_jobs; i++){
		f[i] = IloArray<IloNumVarArray>(*this->environment, nb_jobs);
		for(IloInt j=0; j<nb_jobs; j++){
			f[i][j] = IloNumVarArray(*this->environment, nb_ressources, 0, maxCapacity, ILOFLOAT);
		}
	}

	// FONCTION OBJECTIF
	// ------------------------------
	// On minimise la date à laquelle commence la dernière tache (tâche fictive de durée 0).
	this->model->add(IloMinimize(*this->environment, S[nb_jobs-1]));

	// CONTRAINTES
	// ------------------------------

	// Puit démarre à 0
	this->model->add( S[0] == 0 );

	for(IloInt i=0; i < nb_jobs-1; i++){
		for(IloInt j=i; j < nb_jobs; j++){
			//Contrainte 2 : Impossibilité d'avoir un cycle dans les relations de précédence
			this->model->add( x[i][j] + x[j][i] <= 1 );
		}
	}

	// Arc retour du puit vers la source pour assurer les contraintes de flot
	for(IloInt m=0; m < nb_ressources; m++){
		this->model->add(f[nb_jobs-1][0][m] == this->problem->capacity(m));
	}

	for(IloInt i=0; i < nb_jobs; i++){
		for(IloInt j=0; j < nb_jobs; j++){
			//Contrainte 1 : On fixe les relations de précedence triviales
			// cad présence d'une arête dans le graphe des précédences
			this->model->add( x[i][j] >= this->problem->isSuccessor(i,j));

			for(IloInt k=0; k < nb_jobs; k++){
				//Contrainte 3 Transitivité
				// Si i précede j et j précede k alors i précede k
				this->model->add( x[i][j] + x[j][k] - x[i][k] <= 1 );
			}

			//Contrainte 4
			//Si i précéde j, alors j ne peut commencer qu'après la fin d'exécution de i
			IloInt duration_i = this->problem->jobDuration(i);
			this->model->add(S[j] - S[i] >= - (this->bigM(i,j)) + (duration_i + this->bigM(i,j))*x[i][j] );

			for(IloInt m=0; m < nb_ressources; m++){
				if(i != nb_jobs-1 && j != 0){
					//Contrainte 6 : Qté de flot max pouvant circuler
					// min( flot sortant, qté de flot demandée pour la prochaine tâche).
					IloInt conso_min = std::min(this->problem->consoRessource(i,m),this->problem->consoRessource(j,m));
					this->model->add( f[i][j][m] <= conso_min*x[i][j] );
				}
			}

			//Fixation de variable
			if(this->b[i][j] > this->problem->jobDuration(i)) {
				this->model->add( x[i][j] == 1 );
			} else if (this->b[j][i] >= 1 - this->problem->jobDuration(i)) {
				this->model->add( x[i][j] == 0 );
			}
		}

		for(IloInt m=0; m < nb_ressources; m++){
			//Contrainte 5 : Conservation du flot
			//flot sortant
			IloExpr ctr5a(*this->environment);
			//flot entrant
			IloExpr ctr5b(*this->environment);
			for(IloInt j=0; j < nb_jobs; j++){
				ctr5a += f[i][j][m];
				ctr5b += f[j][i][m];
			}
			this->model->add( ctr5a == this->problem->consoRessource(i,m));
			this->model->add( ctr5b == this->problem->consoRessource(i,m));
			ctr5a.end();
			ctr5b.end();
		}
	}

	// Start between ES and LS
	for(IloInt i=1; i < nb_jobs; i++){
		this->model->add( this->earliestStart(i) <= S[i] );
		this->model->add( S[i] <= this->latestStart(i) );
	}
}
