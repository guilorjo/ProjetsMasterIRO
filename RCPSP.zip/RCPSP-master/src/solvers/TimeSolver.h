/*
 * TimeSolver.h
 *
 *  Created on: 5 déc. 2015
 *      Author: agallastegui
 */
#ifndef _TIMESOLVER_H_
#define _TIMESOLVER_H_
#include <cstdlib>
#include <iostream>
#include "Solver.h"

class TimeSolver : public Solver {
 public:
	TimeSolver(RCPSPInstance* problem);
	virtual ~TimeSolver();
	virtual void initModel();
 };
#endif
