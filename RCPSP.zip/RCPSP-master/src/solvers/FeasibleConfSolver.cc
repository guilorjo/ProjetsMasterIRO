#include "FeasibleConfSolver.h"

#define RC_EPS 1.0e-6

FeasibleConfSolver::FeasibleConfSolver(RCPSPInstance * problem):Solver(problem){
	this->initModel();
}

FeasibleConfSolver::~FeasibleConfSolver(){
}

void FeasibleConfSolver::initModel(){
	// IloInt nb_jobs = this->problem->nbJobs();
	// // IloInt M = this->problem->sumDuration()+1;

	// // INITIALISATION  DES VARIABLES
	// // -----------------------------

	// // Variable x_ij : 1 la tâche j succede i. 0 sinon
	// this->x = IloArray< IloNumVarArray >(*this->environment, nb_jobs);
	// for(IloInt i=0; i<nb_jobs; i++){
	// 	x[i] = IloNumVarArray(*this->environment, nb_jobs, 0, 1, ILOINT);
	// }

	// // Variable S_i : date de début de la tache i
	// this->S = IloNumVarArray(*this->environment, nb_jobs, 0, IloInfinity, ILOINT);

	// // FONCTION OBJECTIF
	// // ------------------------------
	// // On minimise la date à laquelle commence la dernière tache (tâche fictive de durée 0).
	// this->model->add(IloMinimize(*this->environment, S[nb_jobs-1]));

	// // CONTRAINTES
	// // ------------------------------

	// // Puit démarre à 0
	// this->model->add( S[0] == 0 );

	// for(IloInt i=0; i < nb_jobs-1; i++){
	// 	for(IloInt j=i+1; j < nb_jobs; j++){
	// 		//Contrainte 2 : Impossibilité d'avoir un cycle dans les relations de précédence
	// 		this->model->add( x[i][j] + x[j][i] <= 1 );
	// 	}
	// }

	// for(IloInt i=0; i < nb_jobs; i++){
	// 	for(IloInt j=0; j < nb_jobs; j++){
	// 		//Contrainte 1 : On fixe les relations de précedence triviales
	// 		// cad présence d'une arête dans le graphe des précédences
	// 		this->model->add( x[i][j] >= this->problem->isSuccessor(i,j));

	// 		for(IloInt k=0; k < nb_jobs; k++){
	// 			//Contrainte 3 Transitivité
	// 			// Si i précede j et j précede k alors i précede k
	// 			this->model->add( x[i][j] + x[j][k] - x[i][k] <= 1 );
	// 		}

	// 		//Contrainte 4
	// 		//Si i précéde j, alors j ne peut commencer qu'après la fin d'exécution de i
	// 		IloInt duration_i = this->problem->jobDuration(i);
	// 		this->model->add(S[j] - S[i] >= - (this->bigM(i,j)) + (duration_i + this->bigM(i,j))*x[i][j] );

	// 		// Fixation de variable
	// 		if(this->b[i][j] >= this->problem->jobDuration(i)) {
	// 			this->model->add( x[i][j] == 1 );
	// 		} else if (this->b[j][i] >= 1 - this->problem->jobDuration(i)) {
	// 			this->model->add( x[i][j] == 0 );
	// 		}
	// 	}
	// }

	// // Start between ES and LS
	// for(IloInt i=1; i < nb_jobs; i++){
	// 	this->model->add( this->earliestStart(i) <= S[i] );
	// 	this->model->add( S[i] <= this->latestStart(i) );
	// }
}

// void FeasibleConfSolver::solve(){
// 	IloCplex cplex(*this->model);

// 	cplex.use(AllCut(*this->environment, S, x, this->problem));

// 	//cplex.setParam(IloCplex::MIPInterval, 1000);
// 	//cplex.setParam(IloCplex::MIPSearch, IloCplex::Traditional);
// 	cplex.solve();

// 	IloAlgorithm::Status algo_status = cplex.getStatus();
// 	if( algo_status != IloAlgorithm::Optimal ){
// 		this->environment->out() << "Il y a un problème" << std::endl;
// 	} else {
// 		this->environment->out() << "Le modèle a été résolu à l'optimal" << std::endl;
// 		this->environment->out() << "obj.value:  "<< cplex.getObjValue() << std::endl;
// 	}
// }

static void report1 (IloCplex& cutSolver, IloNumVarArray Cut,
                     IloRangeArray Fill)
{
   std::cout << std::endl;
   std::cout << "Using " << cutSolver.getObjValue() << " rolls" << std::endl;
   std::cout << std::endl;
   for (IloInt j = 0; j < Cut.getSize(); j++) {
      std::cout << "  Cut" << j << " = " << cutSolver.getValue(Cut[j]) << std::endl;
   }
   std::cout << std::endl;
   for (IloInt i = 0; i < Fill.getSize(); i++) {
      std::cout << "  Fill" << i << " = " << cutSolver.getDual(Fill[i]) << std::endl;
   }
   std::cout << std::endl;
}

static void report2 (IloAlgorithm& patSolver, IloNumVarArray Use,
                     IloObjective obj)
{
   std::cout << std::endl;
   std::cout << "Reduced cost is " << patSolver.getValue(obj) << std::endl;
   std::cout << std::endl;
   if (patSolver.getValue(obj) <= -RC_EPS) {
      for (IloInt i = 0; i < Use.getSize(); i++)  {
         std::cout << "  Use" << i << " = " << patSolver.getValue(Use[i]) << std::endl;
      }
      std::cout << std::endl;
   }
}

static void report3 (IloCplex& cutSolver, IloNumVarArray Cut)
{
   std::cout << std::endl;
   std::cout << "Best integer solution uses " 
        << cutSolver.getObjValue() << " rolls" << std::endl;
   std::cout << std::endl;
   for (IloInt j = 0; j < Cut.getSize(); j++) {
      std::cout << "  Cut" << j << " = " << cutSolver.getValue(Cut[j]) << std::endl;
   }
}

void FeasibleConfSolver::solve() {
   try {
      IloInt  i, j;

      IloNum      rollWidth;
      IloNumArray amount(*this->environment);
      IloNumArray size(*this->environment);

      /// GET DATA ///
      rollWidth = this->problem->capacity(0);
      for(int i = 0; i < this->problem->nbJobs(); i++) {
      	amount.add(this->problem->jobDuration(i));
      	size.add(this->problem->consoRessource(i, 0));
      }

      /// CUTTING-OPTIMIZATION PROBLEM ///

      IloModel cutOpt (*this->environment);

      IloObjective   RollsUsed = IloAdd(cutOpt, IloMinimize(*this->environment));
      IloRangeArray  Fill = IloAdd(cutOpt,
                                   IloRangeArray(*this->environment, amount, IloInfinity));
      IloNumVarArray Cut(*this->environment);

      IloInt nWdth = size.getSize();
      for (j = 0; j < nWdth; j++) {
         Cut.add(IloNumVar(RollsUsed(1) + Fill[j](int(rollWidth / size[j]))));
      }
      
      IloCplex cutSolver(cutOpt);

      /// PATTERN-GENERATION PROBLEM ///

      IloModel patGen (*this->environment);

      IloObjective ReducedCost = IloAdd(patGen, IloMinimize(*this->environment, 1));
      IloNumVarArray Use(*this->environment, nWdth, 0.0, IloInfinity, ILOINT);
      patGen.add(IloScalProd(size, Use) <= rollWidth);

      IloCplex patSolver(patGen);

      /// COLUMN-GENERATION PROCEDURE ///

      IloNumArray price(*this->environment, nWdth);
      IloNumArray newPatt(*this->environment, nWdth);

      /// COLUMN-GENERATION PROCEDURE ///

      for (;;) {
         /// OPTIMIZE OVER CURRENT PATTERNS ///
       
         cutSolver.solve();
         report1 (cutSolver, Cut, Fill);
       
         /// FIND AND ADD A NEW PATTERN ///
       
         for (i = 0; i < nWdth; i++) {
           price[i] = -cutSolver.getDual(Fill[i]);
         }
         ReducedCost.setLinearCoefs(Use, price);
       
         patSolver.solve();
         report2 (patSolver, Use, ReducedCost);
       
         if (patSolver.getValue(ReducedCost) > -RC_EPS) break;
       
         patSolver.getValues(newPatt, Use);
         Cut.add( IloNumVar(RollsUsed(1) + Fill(newPatt)) );
      }

      cutOpt.add(IloConversion(*this->environment, Cut, ILOINT));

      cutSolver.solve();
      report3 (cutSolver, Cut);
   }
   catch (IloException& ex) {
      std::cerr << "Error: " << ex << std::endl;
   }
   catch (...) {
      std::cerr << "Error" << std::endl;
   }
}