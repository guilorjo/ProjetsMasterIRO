#ifndef _FEASIBLECONFSOLVER_H_
#define _FEASIBLECONFSOLVER_H_

#include <utility>
#include <numeric>
#include <ilcplex/ilocplex.h>
#include "Solver.h"

class FeasibleConfSolver : public Solver {
private:


public:
	FeasibleConfSolver(RCPSPInstance* problem);
	~FeasibleConfSolver();
	void initModel();
	void solve();
};
#endif