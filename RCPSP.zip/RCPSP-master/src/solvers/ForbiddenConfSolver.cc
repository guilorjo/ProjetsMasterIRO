#include "ForbiddenConfSolver.h"

ILOLAZYCONSTRAINTCALLBACK3(AllCut, IloNumVarArray, S, IloArray< IloNumVarArray >, x, RCPSPInstance*, problem){
	IloInt nb_jobs = problem->nbJobs();

	//On trie les S par ordre croissant
	std::vector< std::pair<int, int> > S_tries;
	for(int i=0; i<nb_jobs; i++){
		std::pair<int,int> tmp = std::make_pair(i, getValue(S[i]));
		S_tries.push_back(tmp);
	}
	std::sort(S_tries.begin(), S_tries.end(), [](std::pair<int, int> &left, std::pair<int, int> &right) {
		return left.second < right.second;
	});

	//Tableau avec les taches de S_tries les tâches en cours tabEnCours
	std::vector< std::pair<int, int> > tachesEnCours;
	//Pour tout s \in S_tries :
	for(unsigned int s_index=0; s_index<S_tries.size(); s_index++){
		// Supprimer les tâches terminées enCours (s_i + p_i \leq s)

		tachesEnCours.erase(std::remove_if(tachesEnCours.begin(), tachesEnCours.end(), [s_actual = S_tries[s_index].second, p = problem->duration](const std::pair<int,int>& i){
 			return i.second + p[i.first] <= s_actual;
		}), tachesEnCours.end());

		// Ajouter dans enCours la tâche s
		tachesEnCours.push_back(S_tries[s_index]);

		// std::cout << "taches en cours : " << tachesEnCours.size() << std::endl;
		// Pour toute machine k :
		for (int k = 0; k < this->problem->nbRessources(); ++k) {
			bool configMinimale = false;
			bool configInterdite =  true;

			std::vector<std::pair<int,int> > config = tachesEnCours;
			while(configInterdite && !configMinimale) {
				int exces = 0;
				for(unsigned int tache = 0; tache < config.size(); tache++) {
					exces += problem->consoRessource(config[tache].first, k);
				}
				// std::cout << "exces : " << exces << std::endl;

				// Si sum_{i \in enCours } b_ik - B_k > 0
				configInterdite = false;
				if (exces - problem->capacity(k) > 0) {
					// std::cout << "size : " << config.size() << std::endl;
					configInterdite = true;
					std::pair<int,int> minTachesEnCours = std::make_pair(0, problem->consoRessource(config[0].first, k));
					for(unsigned int h = 1; h < config.size(); h++){
						if(problem->consoRessource(config[h].first, k) < minTachesEnCours.second){
							minTachesEnCours.first = h;
							minTachesEnCours.second = problem->consoRessource(config[h].first, k);
						}
					}
					if(exces - minTachesEnCours.second <= problem->capacity(k)){
						configMinimale = true;
					} else {
						config.erase(config.begin() + minTachesEnCours.first);
					}
				}
			}
			if(configMinimale){
				// std::cout << "TROUVE !" << std::endl;
				IloExpr cut(getEnv());
				for (unsigned int i = 0; i < config.size(); ++i)
				{
					for (unsigned int j = 0; j < config.size(); ++j)
					{
						cut += x[config[i].first][config[j].first];
					}
				}
				add(cut >= 1).end();
				break;
			}
		}
	}
}



ForbiddenConfSolver::ForbiddenConfSolver(RCPSPInstance * problem):Solver(problem){
	this->initModel();
}

ForbiddenConfSolver::~ForbiddenConfSolver(){
}

void ForbiddenConfSolver::initModel(){
	IloInt nb_jobs = this->problem->nbJobs();

	// INITIALISATION  DES VARIABLES
	// -----------------------------

	// Variable x_ij : 1 la tâche j succede i. 0 sinon
	this->x = IloArray< IloNumVarArray >(*this->environment, nb_jobs);
	for(IloInt i=0; i<nb_jobs; i++){
		x[i] = IloNumVarArray(*this->environment, nb_jobs, 0, 1, ILOINT);
	}

	// Variable S_i : date de début de la tache i
	this->S = IloNumVarArray(*this->environment, nb_jobs, 0, IloInfinity, ILOINT);

	// FONCTION OBJECTIF
	// ------------------------------
	// On minimise la date à laquelle commence la dernière tache (tâche fictive de durée 0).
	this->model->add(IloMinimize(*this->environment, S[nb_jobs-1]));

	// CONTRAINTES
	// ------------------------------

	// Puit démarre à 0
	this->model->add( S[0] == 0 );

	for(IloInt i=0; i < nb_jobs-1; i++){
		for(IloInt j=i+1; j < nb_jobs; j++){
			//Contrainte 2 : Impossibilité d'avoir un cycle dans les relations de précédence
			this->model->add( x[i][j] + x[j][i] <= 1 );
		}
	}

	for(IloInt i=0; i < nb_jobs; i++){
		for(IloInt j=0; j < nb_jobs; j++){
			//Contrainte 1 : On fixe les relations de précedence triviales
			// cad présence d'une arête dans le graphe des précédences
			this->model->add( x[i][j] >= this->problem->isSuccessor(i,j));

			for(IloInt k=0; k < nb_jobs; k++){
				//Contrainte 3 Transitivité
				// Si i précede j et j précede k alors i précede k
				this->model->add( x[i][j] + x[j][k] - x[i][k] <= 1 );
			}

			//Contrainte 4
			//Si i précéde j, alors j ne peut commencer qu'après la fin d'exécution de i
			IloInt duration_i = this->problem->jobDuration(i);
			this->model->add(S[j] - S[i] >= - (this->bigM(i,j)) + (duration_i + this->bigM(i,j))*x[i][j] );

			// Fixation de variable
			if(this->b[i][j] > this->problem->jobDuration(i)) {
				this->model->add( x[i][j] == 1 );
			} else if (this->b[j][i] >= 1 - this->problem->jobDuration(i)) {
				this->model->add( x[i][j] == 0 );
			}
		}
	}

	// Start between ES and LS
	for(IloInt i=1; i < nb_jobs; i++){
		this->model->add( this->earliestStart(i) <= S[i] );
		this->model->add( S[i] <= this->latestStart(i) );
	}

	for(int k = 0; k < this->problem->nbRessources(); k++) {
		// Ajout des configurations interdites minimales de taille 2
		std::vector<int> activities(this->problem->nbJobs());
	    int n=0;
	    std::generate(activities.begin(), activities.end(), [&]{ return n++; });
		std::sort(activities.begin(), activities.end(), [prob = this->problem, k = k](int &left, int &right) {
			return prob->consoRessource(left,k) > prob->consoRessource(right,k);
		});
		int firstAct = 0;
		int secondAct = 1;
		while (firstAct < this->problem->nbJobs()-1 &&
		 this->problem->consoRessource(activities[firstAct],k)*2 > this->problem->capacity(k)) {
			if (
				this->problem->consoRessource(activities[firstAct],k)
				+ this->problem->consoRessource(activities[secondAct],k)
				> this->problem->capacity(k)
			) {
				this->model->add(x[activities[firstAct]][activities[secondAct]] + x[activities[secondAct]][activities[firstAct]] >= 1);
				secondAct++;
				if (secondAct >= this->problem->nbJobs()-1) {
					firstAct++;
					secondAct = firstAct+1;	
				}
			} else {
				firstAct++;
				secondAct = firstAct+1;
			}
		}
		// Ajout des configurations interdites minimales suivantes dans l'ordre
		firstAct = 0;
		secondAct = 1;
		std::vector<int> config;
		config.push_back(activities[0]);
		int consoCumul = this->problem->consoRessource(activities[firstAct], k);
		while (firstAct < this->problem->nbJobs()-1) {
			consoCumul += this->problem->consoRessource(activities[secondAct], k);
			config.push_back(activities[secondAct]);
			if (consoCumul > this->problem->capacity(k)) {
				IloExpr cut(*this->environment);
				for (unsigned int i = 0; i < config.size(); ++i) {
					for (unsigned int j = 0; j < config.size(); ++j) {
						cut += x[config[i]][config[j]];
					}
				}
				this->model->add(cut >= 1);
				firstAct++;
				secondAct = firstAct+1;
				consoCumul = this->problem->consoRessource(activities[firstAct], k);
				config.clear();
				config.push_back(activities[firstAct]);

			} else {
				secondAct++;
				if (secondAct >= this->problem->nbJobs()-1) {
					firstAct++;
					secondAct = firstAct+1;	
				}
			}
		}
	}
}

void ForbiddenConfSolver::solve(){
	IloCplex cplex(*this->model);

	cplex.use(AllCut(*this->environment, S, x, this->problem));

	//cplex.setParam(IloCplex::MIPInterval, 1000);
	//cplex.setParam(IloCplex::MIPSearch, IloCplex::Traditional);
	cplex.solve();

	IloAlgorithm::Status algo_status = cplex.getStatus();
	if( algo_status != IloAlgorithm::Optimal ){
		this->environment->out() << "Il y a un problème" << std::endl;
	} else {
		this->environment->out() << "Le modèle a été résolu à l'optimal" << std::endl;
		this->environment->out() << "obj.value:  "<< cplex.getObjValue() << std::endl;
	}
}
