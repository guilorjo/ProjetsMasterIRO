#include <iostream>
#include <cstdlib>
#include "solvers/Solver.h"
#include "solvers/FlowSolver.h"
#include "solvers/TimeSolver.h"
#include "solvers/ForbiddenConfSolver.h"
#include "solvers/FeasibleConfSolver.h"
#include "parser/Parser.h"
#include "problem/RCPSPInstance.h"

int main(int argc, char** argv){

	if(argc != 3){
		std::cout << "Utilisation :" << std::endl
				  << "\t" << argv[0] << " <fichier> <modele>" << std::endl
				  << std::endl
				  << "\t Avec :" << std::endl
				  << "\t\t <fichier> Le fichier contenant l'instance" << std::endl
				  << "\t\t <modele> Le modèle (de 1 à 4, respectivement flot, indexed time, conf interdites, conf réalisables)" << std::endl;
		exit(1);
	}

	std::string filename(argv[1]);
	int methode =  atoi(argv[2]);

	RCPSPInstance* i = new RCPSPInstance(filename);

	switch(methode){
		case 1:
			{
				std::cout << "Modèle 1 : modèle de flots" << std::endl;
				FlowSolver s(i);
				s.solve();
				break;
			}
		case 2:
			{
				std::cout << "Modèle 2 : modèle temps" << std::endl;
				TimeSolver s(i);
				s.solve();
				break;
			}
		case 3:
			{
				std::cout << "Modèle 3 : modèle de configurations interdites minimales" << std::endl;
				ForbiddenConfSolver s(i);
				s.solve();
				break;
			}
		case 4:
			{
				std::cout << "Modèle 4 : modèle de configurations réalisables" << std::endl;
				FeasibleConfSolver s(i);
				s.solve();
				break;
			}
		default:
			std::cout << "Erreur ! modele entre 1 et 4 " << std::endl;
	}

	return EXIT_SUCCESS;
}
