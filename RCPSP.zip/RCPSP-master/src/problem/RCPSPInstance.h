#ifndef _RCPSPINSTANCE_H_
#define _RCPSPINSTANCE_H_

#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <cassert>
#include "../parser/Parser.h"

typedef std::vector< std::vector<int> > matrix ;
class RCPSPInstance {
private:
	int nb_jobs; //ok
	int sum_duration; //ok
	int nb_ressources; //ok

	matrix successors; //ok
	matrix adjacence; //ok

	matrix ressources;//ok

	std::vector<int> ressources_capacity;

public:
	std::vector<int> duration;//ok

	RCPSPInstance(std::string filename);
	~RCPSPInstance();

	std::string toString() const;
	std::string toIBMFormat();

	int nbJobs() const;
	int sumDuration() const;
	int nbRessources() const;
	int isSuccessor(int i, int j) const;
	int jobDuration(int i) const;
	int consoRessource(int i, int m) const;
	int capacity(int m) const;

};
#endif