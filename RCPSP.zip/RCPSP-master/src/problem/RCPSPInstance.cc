#include "RCPSPInstance.h"

RCPSPInstance::RCPSPInstance(std::string filename){
	Parser* p = new Parser(filename);

	std::vector<int> line;

	p->skipLines(5);
	this->nb_jobs = p->getParam();
	this->sum_duration = p->getParam();
	p->skipLines(1);
	this->nb_ressources = p->getParam();
	p->skipLines(9);

	for(int i=0; i<this->nb_jobs; i++){
		p->getData(line);
		std::vector<int> job_successors;
		for(unsigned int j=3; j<line.size(); j++){
			job_successors.push_back(line[j]);
		}
		this->successors.push_back(job_successors);
	}

	p->skipLines(4);

	for(int i=0; i<this->nb_jobs; i++){
		p->getData(line);
		std::vector<int> job_ressources;
		this->duration.push_back(line[2]);
		for(unsigned int j=3; j<line.size(); j++){
			job_ressources.push_back(line[j]);
		}
		this->ressources.push_back(job_ressources);
	}

	p->skipLines(3);
	p->getData(line);

	for(unsigned int i=0; i<line.size(); i++){
		this->ressources_capacity.push_back(line[i]);
	}
	delete p;

	//Compute adjacence
	for(int j=0; j<this->nb_jobs; j++){
		std::vector<int> item_adj;
		for(int i=0; i<this->nb_jobs; i++){
			item_adj.push_back(0);
		}
		for(int i : successors[j]){
			item_adj[i-1] = 1;
		}
		this->adjacence.push_back(item_adj);
	}
}

std::string RCPSPInstance::toString() const {
	std::stringstream description;
	description << "INSTANCE " << std::endl
				<< "#JOBS " << this->nb_jobs << std::endl 
				<< "#SUM_DURATION " << this->sum_duration << std::endl
				<< "#RESSOUCES " << this->nb_ressources << std::endl;

	description << "RESSOURCES CAPACITY ";
	for(unsigned int i=0; i<this->ressources_capacity.size(); i++){
		description << "R" << i << " " << this->ressources_capacity[i] << "   ";
	}
	description << std::endl << std::endl << "JOBS DESCRIPTION " << std::endl;
	for(int i=0; i<this->nb_jobs; i++){
		description << i << " " << this->duration[i] << " R ";
		for(unsigned int j=0; j<this->ressources[i].size(); j++){
			description << this->ressources[i][j] << " ";
		}
		description << "  succ (";
		for(unsigned int j=0; j<this->successors[i].size(); j++){
			description << this->successors[i][j] << " ";
		}
		description << ") " << std::endl;
	}
	return description.str();
}

std::string tab(const std::vector<int>& v){
	std::stringstream description;
	description << "[ " ;
	if( v.size() > 0){
		description  << v[0];
		for(unsigned int i=1; i<v.size(); i++){
			description << " " << v[i];
		}
	}
	description << "]";
	return description.str();
}


std::string mat(const matrix& m){
	assert( m.size() > 0);

	std::stringstream description;
	description << "[ " << tab(m[0]);
	for(unsigned int i=1; i<m.size(); i++){
		description << " " << tab(m[i]);
	}
	description << "]";
	return description.str();
}

std::string RCPSPInstance::toIBMFormat(){
	std::stringstream description;

	description << "Nb_Jobs = " << this->nb_jobs << ";" << std::endl;
	description << "Sum_Duration = " << this->sum_duration << ";" << std::endl;
	description << "Nb_Ressources = " << this->nb_ressources << ";" << std::endl;
	description << "Capacities =" << tab(this->ressources_capacity) <<  ";" << std::endl;
	description << "Durations = " << tab(this->duration) << ";" << std::endl;
	description << "Successors = " << mat(this->adjacence) << ";" << std::endl;
	description << "Ressources = " << mat(this->ressources) << ";" << std::endl;
	return description.str();
}

int RCPSPInstance::nbJobs() const {
	return this->nb_jobs;
}

int RCPSPInstance::sumDuration() const {
	return this->sum_duration;
}

int RCPSPInstance::nbRessources() const {
	return this->nb_ressources;
}

int RCPSPInstance::isSuccessor(int i, int j) const {
	assert( i >= 0 && j>= 0 && i < this->nb_jobs && j < this->nb_jobs ); //Hide for prod
	return this->adjacence[i][j];
}

int RCPSPInstance::jobDuration(int i) const {
	assert( i < this->nb_jobs ); //Hide for prod
	return this->duration[i];
}

int RCPSPInstance::consoRessource(int i, int m) const {
	assert( i < this->nb_jobs && m < this->nb_ressources ); //Hide for prod
	if (i == 0 || i == this->nb_jobs-1) return this->capacity(m);
	return this->ressources[i][m];
}

int RCPSPInstance::capacity(int m) const {
	assert( m < this->nb_ressources ); //Hide for prod
	return this->ressources_capacity[m];
}