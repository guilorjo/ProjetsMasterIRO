#include "KNPItem.h"

namespace data{
	const unsigned int KNPItem::ID = 0;
	const unsigned int KNPItem::WEIGHT = 2;
	const unsigned int KNPItem::PROFIT = 1;

	KNPItem::KNPItem(std::vector<int>& data)
	:Item(data) {}

	KNPItem::~KNPItem(){}

	int KNPItem::getId() const{
		return this->getItemData(ID);
	}

	int KNPItem::getProfit() const{
		return this->getItemData(PROFIT);
	}

	int KNPItem::getWeight() const{
		return this->getItemData(WEIGHT);
	}

	float KNPItem::ranking() const{
		return this->getProfit()/(1.0*this->getWeight());
	}

	bool KNPItem::dominate(const KNPItem& item) const{
		return this->getWeight() < item.getWeight() && this->getProfit() >= item.getProfit();
	}

	std::string KNPItem::toString() const{
		std::stringstream description;
		description << Item::toString()
					<< " ratio: " << this->ranking();
		return description.str();
	}

	bool operator<(const KNPItem& item1, const KNPItem& item2){
		return item2.dominate(item1);
	}
}