#ifndef _KNPITEM_H_
#define _KNPITEM_H_

#include "Item.h"

namespace data{
	class KNPItem : public Item{
		public:
			static const unsigned int ID;
			static const unsigned int WEIGHT;
			static const unsigned int PROFIT;

			KNPItem(std::vector<int>& data);
			~KNPItem();
			int getId() const;
			int getProfit() const;
			int getWeight() const;
			float ranking() const;
			bool dominate(const KNPItem& item) const;
			std::string toString() const;
	};
	bool operator<(const KNPItem& item1, const KNPItem& item2);
}
#endif