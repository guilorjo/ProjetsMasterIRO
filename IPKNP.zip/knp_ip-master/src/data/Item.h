#ifndef _ITEM_H_
#define _ITEM_H_

#include <cassert>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace data{
	class Item{
	private:
		int* data;
		unsigned int size;

	public:
		Item(std::vector<int>& data);
		virtual ~Item();
		int getItemData(unsigned int pos) const;
		unsigned int getSize() const;
		virtual std::string toString() const;
	};
}
#endif