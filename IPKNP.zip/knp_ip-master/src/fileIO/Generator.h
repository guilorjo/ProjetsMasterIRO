#ifndef _GENERATOR_H_
#define _GENERATOR_H_

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>

namespace fileIO{
	class Generator{
	private:
		std::ofstream ostream;

	protected:
		void writeLine(std::vector<int>& data, char delimiter);

	public:
		Generator();
		Generator(std::string filename);
		virtual ~Generator();
		virtual void generate() = 0;
	};
}
#endif