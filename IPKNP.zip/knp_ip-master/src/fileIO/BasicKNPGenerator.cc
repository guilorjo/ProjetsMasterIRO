#include "BasicKNPGenerator.h"

namespace fileIO{
	
	const int BasicKNPGenerator::MIN_CAPACITY = 450;
	const int BasicKNPGenerator::MAX_CAPACITY = 1800;
	const int BasicKNPGenerator::MIN_NB_ITEMS = 1100;
	const int BasicKNPGenerator::MAX_NB_ITEMS = 8000;
	const int BasicKNPGenerator::MIN_PROFIT = 1;
	const int BasicKNPGenerator::MAX_PROFIT = 1500;
	const float BasicKNPGenerator::MAX_WEIGHT_RATIO = 0.4; // max_item_weigth / capacity
	const int BasicKNPGenerator::NB_DATA_BY_ITEM = 3; //(id, profit, weight)
	const char BasicKNPGenerator::DELIMITER = ';';

	BasicKNPGenerator::BasicKNPGenerator(std::string filename)
	:Generator(filename){
		this->capacity = MIN_CAPACITY + rand()%(MAX_CAPACITY - MIN_CAPACITY);
		this->nb_items = MIN_NB_ITEMS + rand()%(MAX_NB_ITEMS - MIN_NB_ITEMS);
		init();
	}

	BasicKNPGenerator::BasicKNPGenerator(std::string filename, int capacity, int nb_items)
	:Generator(filename), capacity(capacity), nb_items(nb_items) {
		this->max_item_weight = round(this->capacity*MAX_WEIGHT_RATIO);
		init();
	}

	void BasicKNPGenerator::init(){
		srand(time(NULL));
		this->max_item_weight = round(this->capacity*MAX_WEIGHT_RATIO);
	}

	int BasicKNPGenerator::randomWeight() const{
		return rand()%this->max_item_weight+1;
	}

	int BasicKNPGenerator::randomProfit() const{
		return MIN_PROFIT + rand()%(MAX_PROFIT - MIN_PROFIT);
	}

	int BasicKNPGenerator::getCapacity() const{
		return this->capacity;
	}

	int BasicKNPGenerator::getNbItems() const{
		return this->nb_items;
	}

	int BasicKNPGenerator::getMaxItemWeight() const{
		return this->max_item_weight;
	}

	void BasicKNPGenerator::generate(){
		std::vector<int> item_data; //(id, profit, weight)
		//First line (max capacity of the bag)
		item_data.push_back(this->capacity);
		this->writeLine(item_data, DELIMITER);
		//Creating all items
		for(unsigned int n=0; n<this->nb_items; n++){
			item_data.push_back(n);
			item_data.push_back(this->randomProfit());
			item_data.push_back(this->randomWeight());
			this->writeLine(item_data,DELIMITER);
		}
	}
}