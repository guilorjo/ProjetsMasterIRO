#include "Convert.h"

namespace fileIO{
	Convert::Convert(std::string filename, char delimiter){
		this->parser = new Parser(filename);

		std::vector<int> line;
		this->parser->getData(line,delimiter);
		this->capacity = line[0];
		while(this->parser->getData(line,delimiter)){
			this->profit.push_back(line[1]);
			this->weight.push_back(line[2]);
		}

	}

	Convert::~Convert(){
		delete this->parser;
	}

	void Convert::convertToIBM(std::string target){
		std::ofstream writefile;
	 	writefile.open(target.c_str(), std::ios::out);

	 	std::stringstream line;

	 	line << "weight = [ ";
		for(int &d : weight){
			line << d << ",";
		}
		line << " ]; " << std::endl;

	 	line << "profit = [ ";
		for(int &d : profit){
			line << d << ",";
		}
		line << " ]; " << std::endl;

		line << "capacite =" << capacity << std::endl;

		writefile << line.str() << std::endl;
	}
}