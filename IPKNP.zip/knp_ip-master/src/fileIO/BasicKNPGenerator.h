#ifndef _BASICKNPGENERATOR_H_
#define _BASICKNPGENERATOR_H_

#include "Generator.h"
#include <ctime>
#include <cstdlib>
#include <cmath>

namespace fileIO{
	class BasicKNPGenerator : public Generator{
	private :
		unsigned int capacity;
		unsigned int nb_items;
		int max_item_weight;
		static const int MIN_CAPACITY;
		static const int MAX_CAPACITY;
		static const int MIN_NB_ITEMS;
		static const int MAX_NB_ITEMS;
		static const int MIN_PROFIT;
		static const int MAX_PROFIT;
		static const float MAX_WEIGHT_RATIO; // max_item_weigth / capacity
		static const int NB_DATA_BY_ITEM; //(id, profit, weight)
		static const char DELIMITER;

		void init();
		int randomWeight() const;
		int randomProfit() const;
	public:
		BasicKNPGenerator(std::string filename);
		BasicKNPGenerator(std::string filename, int capacity, int nb_items);
		int getCapacity() const;
		int getNbItems() const;
		int getMaxItemWeight() const;
		void generate();
	};
}
#endif