#include "CorKNPGenerator.h"

namespace fileIO{
	const float CorKNPGenerator::MAX_WEIGHT_RATIO = 0.4; // max_item_weigth / capacity
	const int CorKNPGenerator::NB_DATA_BY_ITEM = 3; //(id, profit, weight)
	const char CorKNPGenerator::DELIMITER = ';';

	CorKNPGenerator::CorKNPGenerator(std::string filename, int nb_items, int capacity, int cor)
	:Generator(filename), capacity(capacity), nb_items(nb_items){
		this->max_item_weight = round(this->capacity*MAX_WEIGHT_RATIO);
		this->correlation = cor;
		init();
	}

	void CorKNPGenerator::init(){
		srand(time(NULL));
		this->max_item_weight = round(this->capacity*MAX_WEIGHT_RATIO);
	}

	int CorKNPGenerator::randomWeight() const{
		return rand()%this->max_item_weight+1;
	}

	int CorKNPGenerator::randomProfit(int w) const{
		float ratio = 1.0*(1 + pow((-1),(rand()%2+1))*(rand()%this->correlation)/100);
		return round(w*ratio);
	}

	void CorKNPGenerator::generate(){
		std::vector<int> item_data; //(id, profit, weight)
		//First line (max capacity of the bag)
		item_data.push_back(this->capacity);
		this->writeLine(item_data, DELIMITER);
		//Creating all items
		for(unsigned int n=0; n<this->nb_items; n++){
			item_data.push_back(n);

			int w = this->randomWeight();
			int p = this->randomProfit(w);
			item_data.push_back(p);
			item_data.push_back(w);
			this->writeLine(item_data,DELIMITER);
		}
	}
}