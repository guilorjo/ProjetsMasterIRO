#ifndef _CORKNPGENERATOR_H_
#define _CORKNPGENERATOR_H_

#include "Generator.h"
#include <cstdlib>
#include <cmath>
#include <ctime>

namespace fileIO{
	class CorKNPGenerator : public Generator {
	private:
		unsigned int capacity;
		unsigned int nb_items;
		int max_item_weight;
		int correlation;

		static const float MAX_WEIGHT_RATIO; // max_item_weigth / capacity
		static const int NB_DATA_BY_ITEM; //(id, profit, weight)
		static const char DELIMITER;

		void init();
		int randomWeight() const;
		int randomProfit(int w) const;

	public:
		CorKNPGenerator(std::string filename, int nb_items, int capacity, int cor);
		void generate();
	};
}
#endif