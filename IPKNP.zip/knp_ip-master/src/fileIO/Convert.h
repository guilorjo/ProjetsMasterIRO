#ifndef _CONVERT_H_
#define _CONVERT_H_

#include <sstream>
#include <string>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include "Parser.h"

namespace fileIO {
	class Convert {
	private:
		Parser* parser;
		std::vector<int> weight;
		std::vector<int> profit;
		int capacity;

	public:
		Convert(std::string filename, char delimiter);
		~Convert();

		void convertToIBM(std::string target);
	};
}
#endif