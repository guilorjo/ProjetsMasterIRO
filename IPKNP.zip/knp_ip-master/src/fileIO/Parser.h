#ifndef _PARSER_H_
#define _PARSER_H_

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace fileIO{
	class Parser{
	private:
		std::ifstream istream;

	public:
		Parser(std::string filename);
		~Parser();
		bool getData(std::vector<int>& line, char delimiter);
	};
}
#endif