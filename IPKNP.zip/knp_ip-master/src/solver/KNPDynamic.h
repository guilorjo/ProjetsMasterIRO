#ifndef _KNPDYNAMIC_
#define _KNPDYNAMIC_

#include "../app/utils.h"
#include "../problem/Knapsack.h"
#include "../data/Matrix.h"
#include "Solver.h"

namespace solver{
	class KNPDynamic : public Solver {
	private:
		problem::Knapsack* problem;


		std::vector<bool> optimal_solution;

		data::Matrix<int>* profit;
		unsigned int capacity;
		unsigned int nb_items;

		int obj_fun_value;

		void initParameters();
		int getProfit(int remaining_capacity, int item_id);
		void computeSolution();

		float solveProblem();
	public:
		KNPDynamic(problem::Knapsack* problem);
		virtual ~KNPDynamic();

		float getValue() const;
		std::string toString() const;
	};
}
#endif