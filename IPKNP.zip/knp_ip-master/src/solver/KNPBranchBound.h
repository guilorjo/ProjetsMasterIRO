#ifndef _KNPBRANCHBOUND_
#define _KNPBRANCHBOUND_

#include <limits>
#include "KNPLinear.h"
#include "Solver.h"
#include "../app/utils.h"

namespace solver{
	class KNPBranchBound : public Solver{
	private:
		problem::Knapsack* problem;
		KNPLinear* relaxation;

		std::vector<bool> current_solution;
		std::vector<bool> optimal_solution;

		int obj_fun_value;
		int optimal_value;
		
		int remaining_capacity;

		float lower_bound;
		float upper_bound;

		void initParameters();
		
		void addItem(unsigned int i);
		void removeItem(unsigned int i);

		void computeUpperBound(unsigned int i);
		void haveSolution(unsigned int i);
		void plungeFixation(unsigned int& i);

		void searchSolution(unsigned int &i, bool &end);
		bool backtrack(unsigned int& i);


		float solveProblem();

	public:
		KNPBranchBound(problem::Knapsack* problem);
		virtual ~KNPBranchBound();

		float getValue() const;
		std::string toString() const;

	};
}
#endif