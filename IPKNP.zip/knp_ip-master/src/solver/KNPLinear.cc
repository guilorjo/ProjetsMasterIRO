#include "KNPLinear.h"

namespace solver {
	KNPLinear::KNPLinear(problem::Knapsack* problem){
		this->problem = problem;
		this->initParameters(0, this->problem->getNbItems()-1, this->problem->getCapacity());
	}

	KNPLinear::~KNPLinear(){

	}

	void KNPLinear::initParameters(unsigned int begin, unsigned int end, unsigned int capacity){
		this->obj_fun_value = 0;
		this->id_critic_item = this->problem->getNbItems();
		this->remaining_capacity = capacity;
		this->start_item = begin;
		this->end_item = end;
	}

	void KNPLinear::addItem(unsigned int& i){
		if(this->problem->getItemData(i,data::KNPItem::WEIGHT) < this->remaining_capacity){
			this->obj_fun_value += 1.0*this->problem->getItemData(i,data::KNPItem::PROFIT);
			this->remaining_capacity -= this->problem->getItemData(i,data::KNPItem::WEIGHT);
			i++;
		} else {
			float ratio = (1.0*this->remaining_capacity)/(1.0*this->problem->getItemData(i,data::KNPItem::WEIGHT));
			this->obj_fun_value += ratio*this->problem->getItemData(i,data::KNPItem::PROFIT);
			this->remaining_capacity = 0;
			this->id_critic_item = this->problem->getItemData(i,data::KNPItem::ID);
		}
	}

	float KNPLinear::solver(){
		//assert( this->start_item < this->end_item );

		unsigned int i = this->start_item;
		while( i <= this->end_item && remaining_capacity > 0){
			this->addItem(i);
		}
		return this->obj_fun_value;
	}

	float KNPLinear::solveProblemInverseFromTo(unsigned int begin, unsigned int end, unsigned int capacity){
		float p_part1 = this->solveProblemFromTo(0,begin-1,capacity);
		float p_part2 = this->solveProblemFrom(end+1, this->remaining_capacity);
		this->obj_fun_value = p_part1 + p_part2;
		return this->obj_fun_value;
	}

	float KNPLinear::solveProblem(){
		return this->solveProblemFrom(0,this->problem->getCapacity());
	}

	float KNPLinear::solveProblemFrom(unsigned int begin, unsigned int capacity){
		return this->solveProblemFromTo(begin, this->problem->getNbItems()-1, capacity);
	}

	float KNPLinear::solveProblemFromTo(unsigned int begin, unsigned int end, unsigned int capacity){
		this->initParameters(begin, end, capacity);
		return this->solver();
	}

	float KNPLinear::getValue() const {
		return this->obj_fun_value;
	}

	unsigned int KNPLinear::getCriticItem() const {
		return this->id_critic_item;
	}

	std::string KNPLinear::toString() const {
		std::stringstream description;
		description << "Critic item : " << this->getCriticItem()
					<< "  Z* = " << this->obj_fun_value << std::endl;
		return description.str();
	}
}