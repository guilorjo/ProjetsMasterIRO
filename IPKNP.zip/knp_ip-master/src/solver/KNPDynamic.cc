#include "KNPDynamic.h"


namespace solver{
	KNPDynamic::KNPDynamic(problem::Knapsack* problem){
		this->problem = problem;
		this->capacity = this->problem->getCapacity();
		this->nb_items = this->problem->getNbItems();
		this->profit = new data::Matrix<int>(capacity+1, nb_items+1, 0);

		this->initParameters();
	}

	KNPDynamic::~KNPDynamic(){
		delete this->profit;
	}

	void KNPDynamic::initParameters(){
		this->obj_fun_value = 0;
		this->profit->reset(0);
		app::initVector(this->optimal_solution, nb_items, false);
	}

	int KNPDynamic::getProfit(int remaining_capacity, int item_id){
		if( remaining_capacity == 0 || item_id < 0){
			return 0;
		}

		if( remaining_capacity < 0 ){
			return std::numeric_limits<int>::min();
		}

		int item_weight = this->problem->getItemData(item_id,data::KNPItem::WEIGHT);
		int item_profit = this->problem->getItemData(item_id,data::KNPItem::PROFIT);

		int ignore_next_item = getProfit(remaining_capacity, item_id-1);
		int take_next_item = getProfit(remaining_capacity - item_weight, item_id-1) + item_profit;

		this->profit->set(remaining_capacity, item_id, std::max( ignore_next_item , take_next_item ));
		return std::max( ignore_next_item , take_next_item );
	}

	void KNPDynamic::computeSolution(){

		this->profit->setLine(0,0);
		this->profit->setColumn(0,0);

		for(unsigned int remaining_capacity=1; remaining_capacity <= this->capacity; remaining_capacity++){
			for(unsigned int item=1; item <= this->nb_items; item++){
				int new_profit;
				int item_weight = this->problem->getItemData(item-1,data::KNPItem::WEIGHT);
				int item_profit = this->problem->getItemData(item-1,data::KNPItem::PROFIT);

				if(item_weight > remaining_capacity){
					new_profit = this->profit->get(remaining_capacity, item-1);
				}
				else {
					new_profit = std::max(this->profit->get(remaining_capacity, item-1),
										  this->profit->get(remaining_capacity - item_weight, item-1) + item_profit);
				}
				this->profit->set(remaining_capacity, item, new_profit);
			}
		}
	}

	float KNPDynamic::solveProblem(){
		this->initParameters();
		this->computeSolution();
		return getValue();
	}

	float KNPDynamic::getValue() const {
		return 1.0*this->profit->get(capacity,nb_items);
	}

	std::string KNPDynamic::toString() const{
		std::stringstream description;
		//description << this->profit->toString();
		description << "Value " << this->getValue();
		return description.str();
	}
}