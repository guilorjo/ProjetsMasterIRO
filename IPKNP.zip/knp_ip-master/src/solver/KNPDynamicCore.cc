#include "KNPDynamicCore.h"

namespace solver {
	State::State(const state_description& d, const wp_1_to_a& a, unsigned int id, bool t, State* s ){
		this->description = d;
		this->item_id = id;
		this->take_item = t;
		this->previous = s;
		this->sum_to_a = a;
	}

	State::State(const state_description& d, const wp_1_to_a& a){
		this->description = d;
		this->sum_to_a = a;
		this->previous = nullptr;
	}

	State::~State(){
		if(this->previous != nullptr){
			delete this->previous;
		}
	}

	unsigned int State::getItemId() const{
		return this->item_id;
	}

	bool State::getTakeItem() const{
		return this->take_item;
	}

	unsigned int State::getItemA() const {
		return std::get<0>(this->description);
	}

	unsigned int State::getItemB() const {
		return std::get<1>(this->description);
	}

	unsigned int State::getWeight() const {
		return std::get<2>(this->description);
	}

	unsigned int State::getWeightSumToA() const{
		return this->sum_to_a.first;
	}

	unsigned int State::getProfitSumToA() const{
		return this->sum_to_a.second;
	}

	unsigned int State::getWeightCore() const{
		return getWeight() - getWeightSumToA();
	}

	unsigned int State::getProfitCore() const{
		return getProfit() - getProfitSumToA();
	}

	int State::getProfit() const {
		return std::get<3>(this->description);
	}

	State* State::getPreviousState() const {
		return this->previous;
	}

	bool State::dominate(State* b) const{
		if( getItemA() == b->getItemA() &&
			getItemB() == b->getItemB() ){
			return getWeight() <= b->getWeight() && getProfit() >= b->getProfit();
		}
		return false;
	}

	std::string State::toString() const {
		std::stringstream description;
		description << getItemA() << " " << getItemB() << " "
					<< getWeight() << " " << getProfit() << " "
					<< "sum (w,p) " << getWeightCore() << "," << getProfitCore()
					<< " sol-> " << getItemId() << " " << getTakeItem();
		return description.str();
	}


	KNPDynamicCore::KNPDynamicCore(problem::Knapsack* problem){
		this->problem = problem;
		problem->preprocessing();

		this->nb_items = this->problem->getNbItems();
		this->capacity = this->problem->getCapacity();
		this->relaxation = new KNPLinear(problem);
	}


	KNPDynamicCore::~KNPDynamicCore(){
		delete this->relaxation;
	}

	/**
	 * Initiation du solveur
	 * c,c-1 
	**/
	void KNPDynamicCore::initSolver(){
		this->optimal_solution.clear();
		this->incoming_bound = 0;

		unsigned int profit_sum = 0;
		unsigned int weight_sum = 0;
		unsigned int c = round(this->nb_items/2);

		for(unsigned int i=0; i< c; i++){
			profit_sum += this->problem->getItemData(i,data::KNPItem::PROFIT);
			weight_sum += this->problem->getItemData(i,data::KNPItem::WEIGHT);
			this->optimal_solution.push_back(false);
		}

		insert(c,c-1,weight_sum,profit_sum);

		for(unsigned int i=c; i<this->nb_items; i++){
			this->optimal_solution.push_back(false);
		}
	}

	/**
	 * Calcul de la borne supérieure (ok)
	**/
	int KNPDynamicCore::computeUpperBound(State* s){
		return s->getProfitCore() 
				+ this->relaxation->solveProblemInverseFromTo(s->getItemA(), s->getItemB(), this->capacity - s->getWeightCore());
	}


	/**
	 * Calcul de la borne inférieure
	 * 
	**/
	void KNPDynamicCore::updateIncomingBound(){
		int next_incoming_bound = 0;
		core_set::iterator i = this->next_set.begin();
		while( i != this->next_set.end()){
			if((*i)->getProfit() > next_incoming_bound && (*i)->getWeight() <= this->capacity ){
				next_incoming_bound = (*i)->getProfit();
			}
			i++;
		}
		this->incoming_bound = next_incoming_bound;
	}

	/**
	 * Insertion dans la new map et suppression des états dominés 
	**/
	bool KNPDynamicCore::insert(State* s) {
		for(State* i : this->next_set){
			if(i->dominate(s)){ // L'état que l'on veut inserer est dominé
				return true;
			}
			if(s->dominate(i)){ // L'état de la liste est dominé
				this->trash.push_back(i);
			} 
		}
		this->next_set.insert(s);
		this->emptyTrash();
		return false;
	}

	void KNPDynamicCore::insert(unsigned int i, unsigned int j, unsigned int w, int p){
		state_description d(i,j,w,p);
		wp_1_to_a a(w,p);
		insert(new State(d,a));
	}

	bool KNPDynamicCore::stepA(){
		bool end=true;
		for(auto i : this->set){
			unsigned int a = i->getItemA();
			unsigned int b = i->getItemB();
			unsigned int w = i->getWeight();
			int p = i->getProfit();
			unsigned int ws = i->getWeightSumToA();
			unsigned int ps = i-> getProfitSumToA();

			if( a > 0 ){
				end = false;
				int profit = this->problem->getItemData(a-1, data::KNPItem::PROFIT);
				int weight = this->problem->getItemData(a-1, data::KNPItem::WEIGHT);
				wp_1_to_a as(ws-weight, ps-profit);

				insert(new State(state_description(a-1, b, w, p), as, a-1, true, i)); //On garde l'item a
				insert(new State(state_description(a-1, b, w-weight, p-profit), as, a-1, false, i)); //On enlève l'item a
			}
		}
		return end;
	}

	bool KNPDynamicCore::stepB(){
		bool end=true;
		for(auto i : this->set){
			unsigned int a = i->getItemA();
			unsigned int b = i->getItemB();
			unsigned int w = i->getWeight();
			int p = i->getProfit();
			unsigned int ws = i->getWeightSumToA();
			unsigned int ps = i-> getProfitSumToA();
			wp_1_to_a as(ws,ps);
			
			if( b < this->nb_items-1 ){
				end = false;
				int profit = this->problem->getItemData(b+1, data::KNPItem::PROFIT);
				int weight = this->problem->getItemData(b+1, data::KNPItem::WEIGHT);

				insert(new State(state_description(a, b+1, w, p), as, b+1, false, i));
				if( i->getWeightCore() + weight <= this->capacity ){
					insert(new State(state_description(a, b+1, w+weight, p+profit), as, b+1, true, i));
				}
			}
		}
		return end;
	}

	void KNPDynamicCore::emptyTrash(){
		for(auto i : trash){
			this->next_set.erase(i);
		}
		trash.clear();
	}

	void KNPDynamicCore::updateMap(){
		this->updateIncomingBound();

		//Bound elimination
		for(auto i : next_set){
			if(computeUpperBound(i) < this->incoming_bound){
				this->trash.push_back(i);
			}
		}

		this->emptyTrash();
		this->set = this->next_set;
		this->next_set.clear();
	}

	float KNPDynamicCore::solveProblem(){
		this->initSolver();

		bool endA = false;
		bool endB = false;
		do{
			if(!endB) this->updateMap();
			endA = stepA();
			if(!endA) this->updateMap();
			endB = stepB();
		}while(! (endA && endB));

		getSolution();
		return getValue();
	}

	void KNPDynamicCore::getSolution(){
		//Etape 1 selection du gagnant
		int max_profit = 0;
		State* start = nullptr;
		for(auto solution : this->set){
			if(solution->getProfit() >= max_profit && solution->getWeight() <= capacity){
				max_profit = solution->getProfit();
				start = solution;
			}
		}
		this->obj_fun_value = max_profit;
		assert(start != nullptr );

		while(start->getPreviousState() != nullptr){
			this->optimal_solution[start->getItemId()] = start->getTakeItem();
			start = start->getPreviousState();
		}
	}

	float KNPDynamicCore::getValue() const{
		return 1.0*obj_fun_value;
	}

	std::string KNPDynamicCore::toString() const{
		std::stringstream description;
		description << "KNP PROBLEM WITH DYNAMIC CORE " << std::endl;
		/*description << "Optimal solution : " << std::endl;
		description << "[ ";
		for(unsigned int i=0; i < this->optimal_solution.size(); i++){
			//description << i << "=" << this->optimal_solution[i] << " -- ";
			description << this->optimal_solution[i] << " ";
		}
		description << "]";*/
		description << std::endl << "value = " << getValue() << std::endl;
		return description.str();
	}
}