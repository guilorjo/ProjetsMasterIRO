#include "KNPBranchBound.h"

namespace solver{
	KNPBranchBound::KNPBranchBound(problem::Knapsack* problem){
		this->problem = problem;
		this->relaxation = new KNPLinear(problem);
		this->initParameters();
	}

	KNPBranchBound::~KNPBranchBound(){
		delete this->relaxation;
	}

	void KNPBranchBound::initParameters(){
		int nb_items = this->problem->getNbItems();

		this->obj_fun_value = 0;
		this->optimal_value = 0;
		this->remaining_capacity = this->problem->getCapacity();
		this->lower_bound = 0;
		this->upper_bound = std::numeric_limits<float>::max();

		app::initVector(this->current_solution, nb_items, false);
		app::initVector(this->optimal_solution, nb_items, false);
	}

	void KNPBranchBound::addItem(unsigned int i){
		assert( i < this->current_solution.size());
		if(!this->current_solution[i]){
			this->current_solution[i] = true;
			this->remaining_capacity -= this->problem->getItemData(i, data::KNPItem::WEIGHT);
			this->obj_fun_value += this->problem->getItemData(i, data::KNPItem::PROFIT);
		}
	}

	void KNPBranchBound::removeItem(unsigned int i){
		assert( i < this->current_solution.size());
		if(this->current_solution[i]){
			this->current_solution[i] = false;
			this->remaining_capacity += this->problem->getItemData(i, data::KNPItem::WEIGHT);
			this->obj_fun_value -= this->problem->getItemData(i, data::KNPItem::PROFIT);
		}
	}

	void KNPBranchBound::computeUpperBound(unsigned int i){
		assert(i < this->problem->getNbItems());

		float relaxation = this->relaxation->solveProblemFrom(i,this->remaining_capacity);
		this->upper_bound = this->obj_fun_value +  relaxation;
	}

	void KNPBranchBound::haveSolution(unsigned int i){
		unsigned int nb_items = this->problem->getNbItems();
		assert(i == nb_items);

		if(i == nb_items && this->obj_fun_value > this->lower_bound ){
			this->lower_bound = this->obj_fun_value;
			this->optimal_solution = this->current_solution;
			this->optimal_value = this->obj_fun_value;
		}
	}

	void KNPBranchBound::plungeFixation(unsigned int& i){
		unsigned int nb_items = this->problem->getNbItems();
		assert(i < nb_items);

		while( i < nb_items && this->remaining_capacity >= this->problem->getItemData(i,data::KNPItem::WEIGHT)){
			this->addItem(i);
			i++;
		}

		if( i < nb_items ){
			this->current_solution[i] = false;
			i++;
		}
	}

	bool KNPBranchBound::backtrack(unsigned int& i){
		unsigned int nb_items = this->problem->getNbItems();
	
		if(i==nb_items-1 && this->current_solution[i]){
			this->removeItem(i);
		}

		if(app::findPositionFromEnd(this->current_solution.end(), this->current_solution.begin(), true, i)){
			this->removeItem(i);
			i++;
			return false;
		} else {
			return true;
		}
	}

	void KNPBranchBound::searchSolution(unsigned int& i, bool &end){
		unsigned int nb_items = this->problem->getNbItems();

		while(!end && i <  nb_items){
			this->computeUpperBound(i);
			while(this->upper_bound < this->lower_bound && !end){
				end=this->backtrack(i);
				this->computeUpperBound(i);
			}
			this->plungeFixation(i);
		}
	}
	float KNPBranchBound::solveProblem(){
		unsigned int nb_items = this->problem->getNbItems();
		this->initParameters();

		unsigned int current_item = 0;
		bool end = false;
		while(!end){

			this->searchSolution(current_item,end);

			if( current_item == nb_items ){
				this->haveSolution(current_item);
				end = this->backtrack(current_item);
			}
		}

		return this->getValue();
	}

	float KNPBranchBound::getValue() const{
		return 1.0*this->optimal_value;
	}

	std::string KNPBranchBound::toString() const{
		std::stringstream description;
		description << "KNP PROBLEM SOLVED WITH BRANCH & BOUND METHOD" << std::endl;
		/*description	<< "Optimal solution : " << std::endl;
		description << "[ ";
		for(unsigned int i=0; i < this->optimal_solution.size(); i++){
			//description << i << "=" << this->optimal_solution[i] << " -- ";
			description << this->optimal_solution[i] << " ";
		}
		description << "]";*/
		description << std::endl << "Value = " << this->getValue() << std::endl;
		return description.str();
	}
}