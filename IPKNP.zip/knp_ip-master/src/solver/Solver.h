#ifndef _PROBLEM_H_
#define _PROBLEM_H_

#include <chrono>
#include <cstdlib>
#include <iostream>
#include <string>

#include "../app/utils.h"

namespace solver {
	class Solver{
	protected:
		virtual float solveProblem() = 0;

	public:
		Solver();
		virtual ~Solver();
		virtual float getValue() const = 0;
		virtual std::string toString() const = 0;
		float solveVerbose();
		float solve();
	};
}
#endif