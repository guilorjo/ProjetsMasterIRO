#ifndef _KNPDYNAMICCORE_
#define _KNPDYNAMICCORE_

#include "Solver.h"
#include "../problem/Knapsack.h"
#include "KNPLinear.h"
#include <sstream>
#include <set>
#include <tuple>
#include <vector>
#include <string>
#include <iostream>
#include <cassert>

namespace solver{

	typedef std::tuple<int,int,int,int> state_description; //a,b,weight,profit
	typedef std::pair<int,int> wp_1_to_a;
	
	class State {
		state_description description;
		wp_1_to_a sum_to_a; 
		unsigned int item_id;
		bool take_item;
		State* previous;

	public:
		State(const state_description& d, const wp_1_to_a& a , unsigned int id, bool t, State* s);
		State(const state_description& d, const wp_1_to_a& a);
		~State();
		unsigned int getItemId() const;
		bool getTakeItem() const;
		unsigned int getItemA() const;
		unsigned int getItemB() const;
		unsigned int getWeight() const;
		unsigned int getWeightSumToA() const;
		unsigned int getProfitSumToA() const;
		unsigned int getWeightCore() const;
		unsigned int getProfitCore() const;
		int getProfit() const;
		State* getPreviousState() const;
		bool dominate(State* s) const;
		std::string toString() const;
	};

	typedef std::set<State*> core_set;

	class KNPDynamicCore : public Solver{

	private:
		problem::Knapsack* problem;
		KNPLinear* relaxation;

		core_set set;
		core_set next_set;
		std::vector<State*> trash;

		std::vector<bool> optimal_solution;

		unsigned int nb_items;
		unsigned int capacity;
		int incoming_bound;
		int obj_fun_value;

		void initSolver();
		void updateIncomingBound();
		int computeUpperBound(State* s);

		bool insert(State* s);
		void insert(unsigned int i, unsigned int j, unsigned int w, int p);

		bool stepA();
		bool stepB();
		float solveProblem();

		void getSolution();
		
		void emptyTrash();
		void updateMap();

	public:
		KNPDynamicCore(problem::Knapsack* problem);
		virtual ~KNPDynamicCore();

		float getValue() const;
		std::string toString() const;
	};
}
#endif