#ifndef _KNPGRAPH_H_
#define _KNPGRAPH_H_

#include <iostream>
#include <list>
#include <limits>
#include <stack>
#include "../problem/Knapsack.h"
#include "../solver/Solver.h"

namespace solver{

    class AdjRelation {
    private:
        int id;
        int weight;
    public:
        AdjRelation(int i, int w);
        int getId() const;
        int getWeight() const;
    };
     
    class KNPGraph : public Solver {
    private:
        float obj;
        int nb_nodes;
        int source;
        int tap;
        std::list<AdjRelation>* adjacence;
        void addEdge(int u, int v, int weight);
        void createGraph(problem::Knapsack* p);
        void topologicalSort(int current_node, bool visited[], std::stack<int>& stack);
        int longestPath(int s, int t);
        float solveProblem();

    public:
        KNPGraph( problem::Knapsack* p);
        std::string toString() const;
        float getValue() const;
    };
}
#endif