#include "KNPGraph.h"

namespace solver{

	AdjRelation::AdjRelation(int i, int w){
		this->id = i;
		this->weight = w;
	}

	int AdjRelation::getId() const {
		return this->id;
	}

	int AdjRelation::getWeight() const {
		return this->weight;
	}

	KNPGraph::KNPGraph(problem::Knapsack* p) {
		this->obj = 0;
 		unsigned int nb_items = p->getNbItems();
	    unsigned int capacity = p->getCapacity();
	    this->source = (nb_items+1)*(capacity+1);
	    this->tap =  (nb_items+1)*(capacity+1)+1;

	    this->nb_nodes = (nb_items+1)*(capacity+1)+2;
	    this->adjacence = new std::list<AdjRelation>[nb_nodes];

	    for(unsigned int i=0; i<=capacity; i++){
	        addEdge(source,(nb_items+1)*i,0);
	    }

	    for(unsigned int i=0; i<nb_items; i++){
	        for(unsigned int j=0; j<=capacity; j++){
	            unsigned int weight = p->getItemData(i,data::KNPItem::WEIGHT);
	            unsigned int profit = p->getItemData(i,data::KNPItem::PROFIT);

	            if(j+weight <= capacity && i < nb_items){
	                addEdge((nb_items+1)*j + i, (nb_items+1)*(j+weight)+i+1, profit ) ;
	            }
	            addEdge((nb_items+1)*j + i, (nb_items+1)*j+i+1, 0);
	        }
	    }

	    for(unsigned int i=0; i<=capacity; i++){
	        addEdge((nb_items+1)*i + nb_items, tap, 0);
	    }
    }

    void KNPGraph::addEdge(int u, int v, int weight){
    	AdjRelation r(v,weight);
    	this->adjacence[u].push_back(r);
    }

    void KNPGraph::topologicalSort(int current_node, bool visited[], std::stack<int>& stack){
    	visited[current_node] = true;
    	for(auto i : this->adjacence[current_node]){
    		if(!visited[i.getId()]){
    			topologicalSort(i.getId(), visited, stack);
    		}
    	}
    	stack.push(current_node);
    }

    int KNPGraph::longestPath(int s, int t) {
    	//Création de l'ordre topo et enregistrement dans pile
    	std::stack<int> stack;
    	bool* visited = new bool[nb_nodes];
    	for(int i=0; i<nb_nodes; i++){
    		visited[i] = false;
    	}
    	for(int i=0; i<nb_nodes; i++){
    		if(!visited[i]){
    			topologicalSort(i,visited,stack);
    		}
    	}

    	int distance[nb_nodes];
    	for(int i=0; i<nb_nodes; i++){
    		distance[i] = std::numeric_limits<int>::min();
    	}
    	distance[s] = 0;

    	while(!stack.empty()){
    		int current = stack.top();
    		stack.pop();
    		if(distance[current] != std::numeric_limits<int>::min()){
    			for(auto i : adjacence[current]){
    				int lp = distance[current] + i.getWeight();
    				if( distance[i.getId()] < lp ){
    					distance[i.getId()] = lp;
    				}
    			}
    		}
    	}

    	return distance[t];

    }

    float KNPGraph::solveProblem(){
    	obj = 1.0*longestPath(source,tap);
    	return obj;
    }

    float KNPGraph::getValue() const{
    	return obj;
    }

    std::string KNPGraph::toString() const{
    	std::stringstream description;
    	description << "Value " << getValue();
    	return description.str();
    }
}