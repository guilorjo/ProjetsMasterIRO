#ifndef _KNPLINEAR_
#define _KNPLINEAR_

#include "Solver.h"
#include "../fileIO/Parser.h"
#include "../problem/Knapsack.h"

namespace solver{
	class KNPLinear : public Solver {
	private:
		problem::Knapsack* problem;

		unsigned int id_critic_item;
		int remaining_capacity;
		float obj_fun_value;

		unsigned int start_item;
		unsigned int end_item;
		
		void addItem(unsigned int& i);
		float solver();
		float solveProblem();
		void initParameters(unsigned int begin, unsigned int end, unsigned int capacity);

	public:
		KNPLinear(problem::Knapsack* problem);
		~KNPLinear();
		float solveProblemFrom(unsigned int begin, unsigned int capacity);
		float solveProblemFromTo(unsigned int begin, unsigned int end, unsigned int capacity);
		float solveProblemInverseFromTo(unsigned int begin, unsigned int end, unsigned int capacity);
		float getValue() const;
		unsigned int getCriticItem() const;
		std::string toString() const;
	};
}
#endif