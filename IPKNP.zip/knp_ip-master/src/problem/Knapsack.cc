#include "Knapsack.h"

namespace problem{
	Knapsack::Knapsack(std::string filename, char delimiter){
		fileIO::Parser parser(filename);
		std::vector<int> header_line;
		if(parser.getData(header_line, delimiter) && header_line.size()==1){
			this->capacity = header_line[0];
			this->initData(parser, delimiter);
			//this->preprocessing();
		} else {
			std::cerr << "Incorrect header for KNP Problem" << std::endl;
		}
	}

	Knapsack::~Knapsack(){
		for(data::KNPItem* item : this->items){
			delete item;
		}
		this->items.clear();
	}

	void Knapsack::initData(fileIO::Parser& parser, char delimiter){
		std::vector<int> data_line;
		while(parser.getData(data_line,delimiter)){
			this->items.push_back(new data::KNPItem(data_line));
		}
	}

	void Knapsack::preprocessing(){
		auto decrease_ratio = [](data::KNPItem* a, data::KNPItem* b){ return (a->ranking() > b->ranking()); };
		std::sort(this->items.begin(), this->items.end(), decrease_ratio);
	}

	unsigned int Knapsack::getNbItems() const{
		return this->items.size();
	}

	unsigned int Knapsack::getCapacity() const{
		return this->capacity;
	}

	int Knapsack::getItemData(unsigned int i, unsigned int j) const{
		assert(i < this->getNbItems());
		return this->items[i]->getItemData(j);
	}

	std::string Knapsack::toString() const{
		std::stringstream description;
		description << "KNAPSACK PROBLEM" << std::endl
					<< "Capacity : " << this->capacity << std::endl
					<< "# Items : " << this->getNbItems() << std::endl;
		for(data::KNPItem* item : this->items){
			description << item->toString() << std::endl;
		}
		return description.str();
	}
}