#ifndef _KNAPSACK_H_
#define _KNAPSACK_H_

namespace fileIO{
	class Parser;
}
namespace data{
	class KNPItem;
}

#include "../fileIO/Parser.h"
#include "../data/KNPItem.h"
#include <algorithm>

namespace problem{
	class Knapsack {
	private:
		unsigned int capacity; //Knapsack's capacity
		std::vector< data::KNPItem* > items;

		virtual void initData(fileIO::Parser& parser, char delimiter);

	public:
		Knapsack(std::string filename, char delimiter);
		virtual ~Knapsack();
		virtual void preprocessing();
		unsigned int getNbItems() const;
		unsigned int getCapacity() const;
		int getItemData(unsigned int i, unsigned int j) const;
		virtual std::string toString() const;
	};
}
#endif