#include <iostream>
#include <array>
#include <cstdlib>
#include <sstream>
#include "app/utils.h"
#include "fileIO/BasicKNPGenerator.h"
#include "fileIO/CorKNPGenerator.h"
#include "fileIO/Parser.h"
#include "problem/Knapsack.h"
#include "solver/KNPBranchBound.h"
#include "solver/KNPDynamic.h"
#include "fileIO/Convert.h"
#include "solver/KNPDynamicCore.h"
#include "solver/KNPGraph.h"

int main(int argc, char** argv){

/* 
	fileIO::Convert* c = new fileIO::Convert("test", ';');
	c->convertToIBM("IBMtest");
	delete c;
*/

	std::array<int, 7> items = {70, 300, 1000, 5000, 10000, 50000, 100000};
	std::array<int, 7> cap = {100, 400, 1200, 7000, 15000, 100000, 250000};
	std::vector<problem::Knapsack*> p;

	// CRÉATION DES INSTANCES
/*
	for(unsigned int i = 0; i < items.size(); i++){
		std::stringstream file_r; file_r << "play/" << items[i] << "_" << cap[i] << "_random";
		std::stringstream file_lc; file_lc << "play/" << items[i] << "_" << cap[i] << "_lcor";
		std::stringstream file_sc; file_sc << "play/" << items[i] << "_" << cap[i] << "_scor";

		fileIO::Generator* ge1 = new fileIO::BasicKNPGenerator(file_r.str(), cap[i], items[i]);
		ge1->generate();
		delete ge1;

		fileIO::Generator* ge2 = new fileIO::CorKNPGenerator(file_lc.str(), items[i], cap[i], 5);
		ge2->generate();
		delete ge2;

		fileIO::Generator* ge3 = new fileIO::CorKNPGenerator(file_sc.str(), items[i], cap[i], 20);
		ge3->generate();
		delete ge3;
	}


*/
	//EXECUTION
	for(unsigned int i = 0; i < items.size(); i++){
		std::stringstream file_r; file_r << "play/" << items[i] << "_" << cap[i] << "_random";
		std::stringstream file_lc; file_lc << "play/" << items[i] << "_" << cap[i] << "_lcor";
		std::stringstream file_sc; file_sc << "play/" << items[i] << "_" << cap[i] << "_scor";

		p.push_back(new problem::Knapsack(file_r.str(),';'));
		p.push_back(new problem::Knapsack(file_lc.str(),';'));
		p.push_back(new problem::Knapsack(file_sc.str(),';'));
	}

	for(unsigned int i = 0; i < p.size(); i++){
		std::cout << "\n\n\n Probleme #" << p[i]->getNbItems() << " " << i << "\n\n";
		std::cout << std::endl << "**********" << std::endl << "Graph" << std::endl;
		solver::Solver* graph = new solver::KNPGraph(p[i]);
		graph->solveVerbose();
		delete graph;
	}


	/*for(unsigned int i = 0; i < p.size(); i++){
		std::cout << "Problem #" << p[i]->getNbItems() << " " << i << "\n\n";

		p[i]->preprocessing();
		std::cout << std::endl << "**********" << std::endl << "B&B" << std::endl;
		solver::Solver* bab = new solver::KNPBranchBound(p[i]);
		bab->solveVerbose();
		delete bab;


		std::cout << std::endl << "**********" << std::endl << "Dyn" << std::endl;
		solver::Solver* dyn = new solver::KNPDynamic(p[i]);
		dyn->solveVerbose();
		delete dyn;

		std::cout << std::endl << "**********" << std::endl << "Core" << std::endl;
		solver::Solver* core = new solver::KNPDynamicCore(p[i]);
		core->solveVerbose();
		delete core;

		std::cout << std::endl << "**********" << std::endl << "Graph" << std::endl;
		solver::Solver* graph = new solver::KNPGraph(p[i]);
		graph->solveVerbose();
		delete graph;
	}*/







	/*unsigned int nb_items = p->getNbItems();
    unsigned int capacity = p->getCapacity();
    unsigned int source = (nb_items+1)*(capacity+1);
    unsigned int tap =  (nb_items+1)*(capacity+1)+1;

    Graph g((nb_items+1)*(capacity+1)+2);

    for(unsigned int i=0; i<=capacity; i++){
        g.addEdge(source,(nb_items+1)*i,0);
    }

    for(unsigned int i=0; i<nb_items; i++){
        for(unsigned int j=0; j<=capacity; j++){
            unsigned int weight = p->getItemData(i,data::KNPItem::WEIGHT);
            unsigned int profit = p->getItemData(i,data::KNPItem::PROFIT);

            if(j+weight <= capacity && i < nb_items){
                g.addEdge((nb_items+1)*j + i, (nb_items+1)*(j+weight)+i+1, profit ) ;
            }
            g.addEdge((nb_items+1)*j + i, (nb_items+1)*j+i+1, 0);
        }
    }

    for(unsigned int i=0; i<=capacity; i++){
        g.addEdge((nb_items+1)*i + nb_items, tap, 0);
    }
 
    g.longestPath(source,tap);*/

	return EXIT_SUCCESS;
}
