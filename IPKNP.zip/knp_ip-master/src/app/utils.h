#ifndef _UTILS_
#define _UTILS_

#include <cstdlib>
#include <iostream>
#include <vector>

namespace app {
	template<class InputIterator, class T>
	bool findPosition(InputIterator begin, InputIterator end, const T& object, unsigned int& position);

	template<class InputIterator, class T>
	bool findPositionFromEnd(InputIterator end, InputIterator begin, const T& object, unsigned int& position);

	template<class T>
	void initVector(std::vector<T>& vector, unsigned int n, const T& value);

	template<class T>
	void newMatrix(T** matrix, unsigned int m, unsigned int n, T value);

	template<class T>
	void initMatrix(T** matrix, unsigned int m, unsigned int n, T value);

	template<class T>
	void deleteMatrix(T** matrix, unsigned m);
}
#include "utils.tpp"
#endif