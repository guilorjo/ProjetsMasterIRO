#include "Solution.h"

namespace problem{

	Solution::Solution(){ }

	Solution::Solution(std::vector< std::vector<double> >& s, double v){
		this->solution = s;
		this->value = v;
	}

	Solution::~Solution(){}

	double Solution::getValue() const {
		return this->value;
	}

	double Solution::getSolution(unsigned int t, unsigned int i) const {
		return this->solution[i][t];
	}

	void Solution::updateSolution(std::vector< std::vector<double> >& s, double v){
		this->solution = s;
		this->value = v;
	}

	void Solution::update(Solution s){
		this->solution = s.solution;
		this->value = s.value;
	}

	double Solution::getSum(unsigned int t) const{ //debug ok
		assert(t >= 0 && t < this->solution[0].size());
		double sum=0;
		for(unsigned int i=0; i<this->solution.size(); i++){
			sum+=this->solution[i][t];
		}
		return sum;
	}

	std::string Solution::toString() const {
		std::stringstream description;
		for(unsigned int i=0; i<this->solution.size(); i++){
			description << "Item " << i << " > ";
			for(unsigned int t=0; t<this->solution[i].size(); t++){
				description << solution[i][t] << " ";
			}
			description << std::endl;
		}
		return description.str();
	}
}