#include "DynamicSolver.h"

namespace solver {
	DynamicSolver::DynamicSolver(problem::SingleItemLotSizing* p){
		this->problem = p;
		this->best_solution = new problem::Solution();
		this->func_obj = 0;
		for(unsigned int i=0; i<this->problem->getNbPeriods(); i++){
			this->current_pi.push_back(0);
		}
	}

	DynamicSolver::~DynamicSolver(){}

	void DynamicSolver::updatePi(std::vector<double> pi){
		assert(pi.size() == this->problem->getNbPeriods());
		this->current_pi = pi;
	}

	double DynamicSolver::getValue() const {
		return this->best_solution->getValue();
	}

	std::string DynamicSolver::toString() const {
		std::stringstream description;
		description << "Résolution" << std::endl;
		description << "Value = " << this->func_obj << std::endl;
		description << this->best_solution->toString() << std::endl;
		return description.str();
	}

	double DynamicSolver::g(unsigned int i, unsigned int k, unsigned int t, double best, int& demand){ //debug ok
		double prod = this->problem->getPeriodData(k,i,data::LSPeriod::PRODUCTION_COST);
		double setup = this->problem->getPeriodData(k,i,data::LSPeriod::SETUP_COST);
		demand = 0;
		for(unsigned int f=k; f<=t; f++){
			demand += this->problem->getPeriodData(f,i, data::LSPeriod::DEMAND);
		}
		if(demand == 0){
			return best;
		}
		return best + demand*prod + setup + current_pi[k];
	}

	double DynamicSolver::solveForItem(unsigned int i, std::vector<double>& partial_solution){ //debug ok
		std::vector<dyn_solution> best_g;
		partial_solution.clear(); //On vide partial_solution, il faudra le remplir avec la production de chaque période
		int demand;
		dyn_solution init = {0, -1, -1};
		best_g.push_back(init);

		for(unsigned int t=0; t<this->problem->getNbPeriods(); t++){
			partial_solution.push_back(0);
			dyn_solution best_for_t = {std::numeric_limits<double>::max(), 0, 0 };
			for(unsigned int k=0; k<=t; k++){
				double new_value = g(i,k,t, best_g[k].value, demand);
				if(best_for_t.value > new_value){
					best_for_t.value = new_value;
					best_for_t.period = k;
					best_for_t.prod = demand;
				}
			}
			best_g.push_back(best_for_t);
		}

		dyn_solution* p = &best_g[this->problem->getNbPeriods()];
		double value = best_g[this->problem->getNbPeriods()].value;
		while(p->period >= 0){
			partial_solution[p->period] = p->prod;
			p = &best_g[p->period];
		}
		return value;
	}

	double DynamicSolver::solveProblem(){ //debug ok
		double value = 0;
		std::vector< std::vector<double> > solution;
		std::vector<double> partial_solution;

		for(unsigned int i=0; i<this->problem->getNbItems(); i++){
			value += solveForItem(i,partial_solution);
			solution.push_back(partial_solution);
		}

		this->func_obj = value;
		this->best_solution->updateSolution(solution,value);
		return value;
	}

	problem::Solution DynamicSolver::getBestSolution() const{
		return *this->best_solution;
	}
}