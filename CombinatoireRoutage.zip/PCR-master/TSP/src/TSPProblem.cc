#include "TSPProblem.h"

TSPProblem::TSPProblem(TSPData* data){
	this->node_stack = stack<TSPNode*>();
	this->best_path = vector< pair<int,int> >();
	this->upper_bound = numeric_limits<long>::max();
	TSPNode* root = new TSPNode(data->getMatrix(), data->getSize(), vector< pair<int,int> >(), (long)0);
	this->node_stack.push(root);
}

TSPProblem::~TSPProblem(){
	this->best_path.clear();
}

void TSPProblem::run(){
	long current_solution_value;
	pair<int,int> separation_edge;
	
	
	while(!this->node_stack.empty()){
		TSPNode* current_node = this->node_stack.top();
		this->node_stack.pop();
		current_solution_value = current_node->eval();
		//current_node->printMatrix();
		//cout << "cv " << current_solution_value << endl;
		//Comparaison (minimisation)
		if (this->upper_bound > current_solution_value){
			if(current_node->isLeaf()){
				this->upper_bound = current_solution_value;
				this->best_path = current_node->getSelectedEdges();
			} else {
				//Choix arc
				separation_edge = current_node->separateEdgeChoice();
				//Création des fils
				createNodeForbidden(current_node, separation_edge);
				createNodeAllowed(current_node, separation_edge);
			}
		}
		delete current_node;
	}
}

void TSPProblem::createNodeAllowed(TSPNode* father, pair<int,int> separate_edge){
	TSPNode* child = new TSPNode(*father);
	child->addSelectedEdge(separate_edge);
	this->node_stack.push(child);
}

void TSPProblem::createNodeForbidden(TSPNode* father, pair<int,int> separate_edge){
	TSPNode* child = new TSPNode(*father);
	child->addForbiddenEdge(separate_edge);
	this->node_stack.push(child);
}

long TSPProblem::getBestSolution(){
	return this->upper_bound;
}
