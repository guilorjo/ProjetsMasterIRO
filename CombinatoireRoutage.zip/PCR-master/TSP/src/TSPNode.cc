#include "TSPNode.h"

using namespace std;

const long infinity = numeric_limits<long>::max();

TSPNode::TSPNode(long ** matrix, int size, vector< pair<int,int> > selected_edges, long lower_bound){
	this->matrix = new long*[size];
	for(int i=0; i<size; i++){
		this->matrix[i] = new long[size];
		for(int j=0; j<size; j++){
			this->matrix[i][j] = matrix[i][j];
		}
	}
	this->size = size;
	this->selected_edges = selected_edges;
	
	this->lower_bound = lower_bound;
	preprocessLowerBound();
}

TSPNode::TSPNode(const TSPNode& node){
	this->size = node.size;
	this->lower_bound = node.lower_bound;

	this->selected_edges = vector< pair<int,int> >();
	this->selected_edges.reserve(node.selected_edges.size());
	copy(node.selected_edges.begin(), node.selected_edges.end(), back_inserter(this->selected_edges));

	this->matrix = new long*[node.size];
	for(unsigned int i=0; i<node.size; i++){
		this->matrix[i] = new long[node.size];
		for(unsigned int j=0; j<node.size; j++){
			this->matrix[i][j] = node.matrix[i][j];
		}
	}
	preprocessLowerBound();	
}

TSPNode::~TSPNode(){
	for(unsigned int i=0;i<this->size;++i){
		delete[] matrix[i];
	}
	delete[] matrix;
	this->selected_edges.clear();
}


/* retourne la matrice de doubles */
long ** TSPNode::getMatrix(){
	return matrix;
}

/* retourne la taille du probleme lu */
int TSPNode::getSize() const {
	return size;
}

/* retourne la distance entre i et j */
long TSPNode::getVal(int i, int j) const {
	return matrix[i][j];
}

/* to do */
vector< pair<int,int> > TSPNode::getSelectedEdges() const{
	return selected_edges;
}

// Complexité size²
void TSPNode::preprocessLowerBound() {
	long borne_inf=0;
	
	long min_ligne = numeric_limits<long>::max();
	
	for(unsigned int l = 0; l < this->size; l++){
		for(unsigned int c = 0; c<size; c++){
			min_ligne = min( min_ligne,this->matrix[l][c] );
		}
		
		for(unsigned int c = 0; c< this->size; c++){
			if(this->matrix[l][c] != infinity){
				this->matrix[l][c] -= min_ligne;
			}
		}
		
		borne_inf += min_ligne;
		min_ligne = numeric_limits<long>::max();
	}
	
	long min_colonne = numeric_limits<long>::max();
	
	for(unsigned int c = 0; c < this->size; c++){
		for(unsigned int l = 0; l<size; l++){
			min_colonne = min( min_colonne, this->matrix[l][c] );
		}
		
		for(unsigned int l = 0 ; l < this->size; l++){
			if(this->matrix[l][c] != numeric_limits<long>::max()){
				this->matrix[l][c] -= min_colonne;
			}
		}
		
		borne_inf += min_colonne;
		min_colonne = numeric_limits<long>::max();
	}

	//cout << "preproc " << this->lower_bound << " - " << borne_inf << endl;
	if(this->lower_bound != numeric_limits<long>::max()){
		this->lower_bound += borne_inf;
	}
}


pair<int,int> TSPNode::separateEdgeChoice(){
	int line = 0;
	int column = 0;
	long upper_regret = 0;
	long* columns_regret = new long[this->size];
	long* lines_regret = new long[this->size];
	bool* columns_zero = new bool[this->size];
	bool* lines_zero = new bool[this->size];

	for(unsigned int i=0; i<this->size; i++){
		columns_zero[i] = false;
		lines_zero[i] = false;
		lines_regret[i] = numeric_limits<long>::max();
		columns_regret[i] = numeric_limits<long>::max();
	}

	for(unsigned int i=0; i<this->size; i++){
		for(unsigned int j=0; j<this->size; j++){
			if(this->matrix[i][j] == 0){
				if(lines_zero[i]){
					lines_regret[i] = 0; //2 zeros sur la ligne, regret = 0
				} else {
					lines_zero[i] = true; //1 zero sur la ligne
				}
				if(columns_zero[j]){
					columns_regret[j] = 0;
				} else {
					columns_zero[j] = true;
				}
			} else {
				lines_regret[i] = min(lines_regret[i], this->matrix[i][j]);
				columns_regret[j] = min(columns_regret[j], this->matrix[i][j]);
			}
		}
	}

	for(unsigned int i=0; i<this->size; i++){
		for(unsigned int j=0; j<this->size; j++){
			if(this->matrix[i][j] == 0){

				long regret =  numeric_limits<long>::max();
				if(lines_regret[i] != numeric_limits<long>::max() && columns_regret[i] != numeric_limits<long>::max()){
					regret = lines_regret[i] + columns_regret[j];
				}

				if(regret > upper_regret && this->selected_edges.end() == find(this->selected_edges.begin(), this->selected_edges.end(), pair<int,int>(i,j))){
					line = i;
					column = j;
					upper_regret = regret;
				}
			}
		}
	}
	//cout << "regret = " << line << "," << column << " " << upper_regret << endl;
	delete[] columns_regret;
	delete[] lines_regret;
	delete[] columns_zero;
	delete[] lines_zero;
	return pair<int,int>(line,column);
}

// Ajoute un arc selectionné
void TSPNode::addSelectedEdge(pair<int,int> edge){
	int i = edge.first;
	int j = edge.second;
	
	//Interdictions des arcs
	for(unsigned int k=0; k<this->size; k++){
		this->matrix[k][j] = numeric_limits<long>::max();
		this->matrix[i][k] = numeric_limits<long>::max();
	}
	//Interdiction du sous tour le plus grand contenant l'arête ajoutée
	// Ou ajout si c'est la dernière arête
	deque<int> subtour;
	subtour.push_back(i);
	subtour.push_back(j);
	bool found_edge = true;
	while (found_edge) {
		found_edge = false;
		for(vector< pair<int,int> >::iterator it = this->selected_edges.begin(); it != this->selected_edges.end(); it++){
			// determine if "check" goes before in a subtour
			if ((*it).second == subtour.front()) {
				subtour.push_front((*it).second);
				subtour.push_front((*it).first);
				found_edge = true;
				break;
			}

			// determine if "check" goes after in a subtour
			else if ((*it).first == subtour.back()) {
				subtour.push_back((*it).first);
				subtour.push_back((*it).second);
				found_edge = true;
				break;
			}
		}
	}
	
	this->selected_edges.push_back(edge);

	// make the ends of the longest subtour infinite or add it
	if (this->selected_edges.size() == this->size - 1) {
		this->lower_bound += this->matrix[subtour.back()][subtour.front()];
	} else {
		this->matrix[subtour.back()][subtour.front()] = infinity;
	}
	
	this->matrix[i][j] = 0; //A voir
}

//Ajoute arête interdite
void TSPNode::addForbiddenEdge(pair<int,int> edge){
	int i = edge.first;
	int j = edge.second;
	this->matrix[i][j] = infinity;
	long line_regret = this->matrix[i][0];
	long column_regret = this->matrix[0][j];

	for(unsigned int k=1; k<this->size; k++){
		if(this->matrix[i][k] < line_regret){
			line_regret = this->matrix[i][k];
		}
		if(this->matrix[k][j] < column_regret){
			column_regret = this->matrix[k][j];
		}
	}

	if(line_regret == infinity || column_regret == infinity){
		this->lower_bound = infinity;
	} else {
		for(unsigned int k=0; k<this->size; k++){
			if (this->matrix[i][k] != infinity){
				this->matrix[i][k] -= line_regret;
			}
			if(this->matrix[k][j] != infinity){
				this->matrix[k][j] -= column_regret;
			}
		}
		this->lower_bound += line_regret + column_regret;
	}
}

bool TSPNode::isLeaf(){
	return this->selected_edges.size() == this->size;
}

/* Valeur de la solution */
long TSPNode::eval(){
	return this->lower_bound;
}

void TSPNode::printMatrix(){
	for (unsigned int i = 0; i < size; ++i) { // calcul des distances
		for (unsigned int j = 0; j < size; ++j) {
			if( matrix[i][j] == numeric_limits<long>::max()){
				cout << "inf | ";
			} else {
				cout << matrix[i][j] << " | ";
			}
		}
		cout << endl;
	}
cout << endl;cout << endl;cout << endl;
}

