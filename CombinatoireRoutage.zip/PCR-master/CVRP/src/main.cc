#include "CVRPData.h"
#include "CVRPProblem.h"
using namespace std;

int main(int argc, char** argv){

	if (argc > 1) {
		CVRPData cvrp(argv[1]);
		cout << cvrp << endl;
		
		CVRPProblem problem(&cvrp);
	}

	return 0;
}
