#include "CVRPData.h"

CVRPData::CVRPData(const char* filename){
  std::ifstream infile;
  int tmp;
  infile.open(filename,std::ios::in);
  nb_nodes = 0;

  /* Reading of the data in file filename */
  char* ligne = new char[256];
  do {
    infile >> ligne >> std::ws;
  } while ((strcmp(ligne,"TYPE:") != 0) && (!infile.eof()));

  if (infile.eof()){
    std::cout << "Bad file (type not specified) !!!" << std::endl;
    abort();
  }

  infile >> ligne >> std::ws;

  if (strcmp(ligne,"CVRP") == 0){
    do {
      infile >> ligne >> std::ws;
    } while ((strcmp(ligne,"DIMENSION:") != 0) && (!infile.eof()));

    if (infile.eof()){
      std::cout << "Bad File (dimension not specified) !!!" << std::endl;
      abort();
    }

    infile >> this->nb_nodes >> std::ws;

    this->distances = new int*[this->nb_nodes];
    for (int i = 0; i < this->nb_nodes; i++){
      this->distances[i] = new int[this->nb_nodes];
    }

    this->demands = new int[this->nb_nodes];

    do {
      infile >> ligne >> std::ws;
    } while ((strcmp(ligne,"EDGE_WEIGHT_TYPE:") != 0) && (!infile.eof()));

    infile >> ligne >> std::ws;

    if (strcmp(ligne,"EXPLICIT") == 0){

      do {
	infile >> ligne >> std::ws;
      } while ((strcmp(ligne,"EDGE_WEIGHT_FORMAT:") != 0) && (!infile.eof()));

      infile >> ligne >> std::ws;

      if (strcmp(ligne,"FULL_MATRIX") == 0){
	do {
	  infile >> ligne >> std::ws;
	} while ((strcmp(ligne,"CAPACITY:") != 0) && (!infile.eof()));

	infile >> this->capacity >> std::ws;

	do {
	  infile >> ligne >> std::ws;
	} while ((strcmp(ligne,"EDGE_WEIGHT_SECTION") != 0) && (!infile.eof()));

	if (infile.eof()){
	  std::cout << "Bad File (no arc specified) !!!" << std::endl;
	  abort();
	}

	infile >> std::ws;
	for (int i = 0; i < this->nb_nodes; i++){
	  for (int j = 0; j < this->nb_nodes; j++){
	    infile >> this->distances[i][j] >> std::ws;
	  }
	  this->distances[i][i] = std::numeric_limits<int>::max();
	}

	do {
	  infile >> ligne >> std::ws;
	} while ((strcmp(ligne,"DEMAND_SECTION") != 0) && (!infile.eof()));

	for (int i = 0; i < this->nb_nodes; i++){
	  infile >> tmp >> this->demands[i] >> std::ws;
	}


      } else {
	if (strcmp(ligne,"UPPER_ROW") == 0) {

	  do {
	    infile >> ligne >> std::ws;
	  } while ((strcmp(ligne,"CAPACITY:") != 0) && (!infile.eof()));

	  infile >> this->capacity >> std::ws;

	  do {
	    infile >> ligne >> std::ws;
	  } while ((strcmp(ligne,"EDGE_WEIGHT_SECTION") != 0) && (!infile.eof()));

	  if (infile.eof()){
	    std::cout << "Bad File (no arc specified) !!!" << std::endl;
	    abort();
	  }

	  infile >> std::ws;
	  for (int i = 0; i < this->nb_nodes-1; i++){
	    for (int j = i+1; j < this->nb_nodes; j++){
	      infile >> this->distances[i][j] >> std::ws;
	      this->distances[j][i] = this->distances[i][j];
	    }
	    this->distances[i][i] = std::numeric_limits<int>::max();
	  }
	  this->distances[this->nb_nodes-1][this->nb_nodes-1] = std::numeric_limits<int>::max();

	  do {
	    infile >> ligne >> std::ws;
	  } while ((strcmp(ligne,"DEMAND_SECTION") != 0) && (!infile.eof()));

	  for (int i = 0; i < this->nb_nodes; i++){
	    infile >> tmp >> this->demands[i] >> std::ws;
	  }

	} else {
	  if (strcmp(ligne,"LOWER_DIAG_ROW") == 0){
	    do {
	      infile >> ligne >> std::ws;
	    } while ((strcmp(ligne,"CAPACITY:") != 0) && (!infile.eof()));

	    infile >> this->capacity >> std::ws;

	    do {
	      infile >> ligne >> std::ws;
	    } while ((strcmp(ligne,"EDGE_WEIGHT_SECTION") != 0) && (!infile.eof()));

	    if (infile.eof()){
	      std::cout << "Bad File (no arc specified) !!!" << std::endl;
	      abort();
	    }

	    infile >> std::ws;
	    for (int i = 0; i < this->nb_nodes; i++){
	      for (int j = 0; j <= i; j++){
		infile >> this->distances[i][j] >> std::ws;
		this->distances[j][i] = this->distances[i][j];
	      }
	      this->distances[i][i] = std::numeric_limits<int>::max();
	    }

	    do {
	      infile >> ligne >> std::ws;
	    } while ((strcmp(ligne,"DEMAND_SECTION") != 0) && (!infile.eof()));

	    for (int i = 0; i < this->nb_nodes; i++){
	      infile >> tmp >> this->demands[i] >> std::ws;
	    }

	  } else {
	    if (strcmp(ligne,"LOWER_ROW") == 0){
	      do {
		infile >> ligne >> std::ws;
	      } while ((strcmp(ligne,"CAPACITY:") != 0) && (!infile.eof()));

	      infile >> this->capacity >> std::ws;

	      do {
		infile >> ligne >> std::ws;
	      } while ((strcmp(ligne,"EDGE_WEIGHT_SECTION") != 0) && (!infile.eof()));

	      if (infile.eof()){
		std::cout << "Bad File (no arc specified) !!!" << std::endl;
		abort();
	      }

	      infile >> std::ws;
	      for (int i = 0; i < this->nb_nodes; i++){
		for (int j = 0; j < i; j++){
		  infile >> this->distances[i][j] >> std::ws;
		  this->distances[j][i] = this->distances[i][j];
		}
		this->distances[i][i] = std::numeric_limits<int>::max();
	      }

	      do {
		infile >> ligne >> std::ws;
	      } while ((strcmp(ligne,"DEMAND_SECTION") != 0) && (!infile.eof()));

	      for (int i = 0; i < this->nb_nodes; i++){
		infile >> tmp >> this->demands[i] >> std::ws;
	      }

	    } else {
	      std::cout << "Edge weight format not supported" << std::endl;
	      abort();
	    }
	  }
	}
      }

    } else {
      if (strcmp(ligne,"EUC_2D") == 0){
	do {
	  infile >> ligne >> std::ws;
	} while ((strcmp(ligne,"CAPACITY:") != 0) && (!infile.eof()));

	infile >> this->capacity >> std::ws;

	do {
	  infile >> ligne >> std::ws;
	} while ((strcmp(ligne,"NODE_COORD_SECTION") != 0) && (!infile.eof()));

	if (infile.eof()){
	  std::cout << "Bad File (no node specified) !!!" << std::endl;
	  abort();
	}

	std::vector<float> coordx(this->nb_nodes);
	std::vector<float> coordy(this->nb_nodes);
	int temp;

	infile >> std::ws;
	for (int i = 0; i < this->nb_nodes; i++){
	  infile >> temp >> coordx[i] >> coordy[i] >> std::ws;
	}

	for (int i = 0; i < this->nb_nodes-1; i++){
	  for (int j = i+1; j < this->nb_nodes; j++){
	    float xd = coordx[i] - coordx[j];
	    float yd = coordy[i] - coordy[j];
	    this->distances[i][j] = floor(sqrt(xd*xd + yd*yd) + 0.5);
	    this->distances[j][i] = this->distances[i][j];
	  }
	  this->distances[i][i] = std::numeric_limits<int>::max();
	}
	this->distances[this->nb_nodes-1][this->nb_nodes-1] = std::numeric_limits<int>::max();

	do {
	  infile >> ligne >> std::ws;
	} while ((strcmp(ligne,"DEMAND_SECTION") != 0) && (!infile.eof()));

	for (int i = 0; i < this->nb_nodes; i++){
	  infile >> tmp >> this->demands[i] >> std::ws;
	}

      } else {
	if (strcmp(ligne,"GEO") == 0){

	  double PI=3.141592;
	  double RRR=6378.388;

	  do {
	    infile >> ligne >> std::ws;
	  } while ((strcmp(ligne,"CAPACITY:") != 0) && (!infile.eof()));

	  infile >> this->capacity >> std::ws;

	  do {
	    infile >> ligne >> std::ws;
	  } while ((strcmp(ligne,"NODE_COORD_SECTION") != 0) && (!infile.eof()));

	  if (infile.eof()){
	    std::cout << "Bad File (no node specified) !!!" << std::endl;
	    abort();
	  }

	  std::vector<float> latitude(this->nb_nodes);
	  std::vector<float> longitude(this->nb_nodes);
	  int temp,deg;
	  float xi,yi,min;

	  infile >> std::ws;
	  for (int i = 0; i < this->nb_nodes; i++){
	    infile >> temp >> xi >> yi >> std::ws;
	    deg = floor(xi + 0.5);
	    min = xi - deg;
	    latitude[i] = PI * (deg + 5.0 * min / 3.0) / 180.0;
	    deg = floor(yi + 0.5);
	    min = yi - deg;
	    longitude[i] = PI * (deg + 5.0 * min / 3.0) / 180.0;
	  }

	  for (int i = 0; i < this->nb_nodes; i++){
	    for (int j = 0; j < this->nb_nodes; j++){
	      if (i != j){
		float q1 = cos(longitude[i] - longitude[j]);
		float q2 = cos(latitude[i] - latitude[j]);
		float q3 = cos(latitude[i] + latitude[j]);
		this->distances[i][j] = floor (RRR * acos(0.5 * (( 1.0 + q1) * q2 - (1.0 - q1)*q3)) + 1.0);
	      }
	    }
	    this->distances[i][i] = std::numeric_limits<int>::max();
	  }

	  do {
	    infile >> ligne >> std::ws;
	  } while ((strcmp(ligne,"DEMAND_SECTION") != 0) && (!infile.eof()));
	  
	  for (int i = 0; i < this->nb_nodes; i++){
	    infile >> tmp >> this->demands[i] >> std::ws;
	  }


	} else {
	  std::cout << "Edge weight type not supported" << std::endl;
	  abort();
	}
      }

    }
  } else {
    std::cout << "Problem not supported" << std::endl;
  }

  infile.close();
}

CVRPData::~CVRPData(){
  for (int i = 0; i < this->nb_nodes; i++){
    delete[] this->distances[i];
  }
  delete[] this->distances;
  delete[] this->demands;
}

int CVRPData::getCapacity() const {
  return this->capacity;
}

int CVRPData::getSize() const {
  return this->nb_nodes;
}

int** CVRPData::getDistances() const {
  return this->distances;
}

int CVRPData::getDistance(const int & i, const int & j) const {
  return this->distances[i][j];
}

int* CVRPData::getDemands() const {
  return this->demands;
}

int CVRPData::getDemand(const int & i) const {
  return this->demands[i];
}

std::ostream & operator<<(std::ostream & os, const CVRPData & cvrp){
  os << "Size = " << cvrp.getSize() << std::endl;
  os << "Capacity = " << cvrp.getCapacity() << std::endl;
  os << "Distances :" << std::endl;
  for (int i = 0; i < cvrp.getSize(); i++){
    for (int j = 0; j < cvrp.getSize(); j++){
      os << cvrp.getDistance(i,j) << " - ";
    }
    os << std::endl;
  }
  os << "Demands :" << std::endl;
  for (int i = 0; i < cvrp.getSize(); i++){
    os << cvrp.getDemand(i) << " - ";
  }

  return os;
}
