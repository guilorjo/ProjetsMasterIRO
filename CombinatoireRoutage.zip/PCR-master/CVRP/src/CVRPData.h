#ifndef _CVRPDATA_H_
#define _CVRPDATA_H_

#include <cmath>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <vector>

class CVRPData {
private :
  int capacity;
  int nb_nodes;
  int ** distances;
  int * demands;

public :
  CVRPData(const char* filename);
  ~CVRPData();
  int getCapacity() const;
  int getSize() const;
  int** getDistances() const;
  int* getDemands() const;
  int getDistance(const int & i, const int & j) const;
  int getDemand(const int & i) const;
};

std::ostream & operator<<(std::ostream & os, const CVRPData & cvrp);
#endif
