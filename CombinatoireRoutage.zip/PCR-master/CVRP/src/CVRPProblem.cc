#include "CVRPProblem.h"

using namespace std;

CVRPProblem::CVRPProblem(CVRPData* data){
	this->data = data;
	preprocessGainFusion();
}

CVRPProblem::~CVRPProblem(){
}

//Matrice contenant les gains
void CVRPProblem::preprocessGainFusion(){
	for(int i=0; i<this->data->getSize(); i++){
		for(int j=0; j<this->data->getSize(); j++){
			if (i != j && i != 0 && j != 0) {
				CVRPGain g(i, j, this->data->getDistance(0,i) + this->data->getDistance(0,j) - this->data->getDistance(i,j));
				this->heap_gains.push(g);
			}
		}
	}
}

int CVRPProblem::getSize() const{
	return this->data->getSize();
}
