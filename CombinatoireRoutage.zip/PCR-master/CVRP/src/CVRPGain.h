#ifndef _CVRPGAIN_H_
#define _CVRPGAIN_H_

#include <cstdlib>

class CVRPGain{
	private:
		int i;
		int j;
		int gain;
	public:
		CVRPGain(int i, int j, int gain);
		int getGain() const;
};
bool operator <(CVRPGain const &g1, CVRPGain const &g2);
#endif

