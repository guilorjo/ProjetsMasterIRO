#ifndef _CVRPPROBLEM_H_
#define _CVRPPROBLEM_H_
#include <cstdlib>
#include <iostream>
#include <queue>

#include "CVRPData.h"
#include "CVRPGain.h"

class CVRPProblem {
private:
	CVRPData* data;
	std::priority_queue<CVRPGain> heap_gains;
	
	void preprocessGainFusion();
public:
	CVRPProblem(CVRPData* data);
	~CVRPProblem();
	int getSize() const;
};
#endif
