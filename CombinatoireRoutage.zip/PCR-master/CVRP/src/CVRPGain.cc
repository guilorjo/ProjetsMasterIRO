#include "CVRPGain.h"

using namespace std;

CVRPGain::CVRPGain(int i, int j, int gain) {
	this->i = i;
	this->j = j;
	this->gain = gain;
}

int CVRPGain::getGain() const{
	return this->gain;
}

bool operator <(CVRPGain const &g1, CVRPGain const &g2) {
	return g1.getGain() < g2.getGain();
}
