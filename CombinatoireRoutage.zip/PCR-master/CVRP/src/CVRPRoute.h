#ifndef _CVRPROUTE_H_
#define _CVRPROUTE_H_

#include <cstdlib>
#include <list>

class CVRPRoute{
	private:
		std::list<int> path;
		int demands;
	public:
		CVRPRoute(std::list<int> nodes, int demand);
		CVRPRoute(CVRPRoute const &path);
		int getBegin() const;
		int getEnd() const;
		int getDemands() const;
};
#endif
