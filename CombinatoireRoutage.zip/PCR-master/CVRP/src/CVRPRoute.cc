#include "CVRPRoute.h"

using namespace std;

CVRPRoute::CVRPRoute(std::list<int> nodes, int demand){
	this->path = nodes;
	this->demands = demand;
}

CVRPRoute::CVRPRoute(CVRPRoute const &path){
	this->demands += path.getDemands(); 
}

int CVRPRoute::getBegin() const{
	return this->path->front();
}

int CVRPRoute::getEnd() const{
	return this->path->back();
}

int CVRPRoute::getDemands() const{
	return this->demands;
}
