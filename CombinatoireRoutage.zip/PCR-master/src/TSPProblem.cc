#include "TSPProblem.h"

TSPProblem::TSPProblem(TSPData* data){
	this->size = data->getSize();
	this->node_stack = stack<TSPNode*>();
	this->best_path = vector< pair<int,int> >();
	this->upper_bound = numeric_limits<long>::max();
	TSPNode* root = new TSPNode(data->getMatrix(), data->getSize(), vector< pair<int,int> >(), (long)0);
	this->node_stack.push(root);
	this->visitedNodes = 0;
	this->cutedNodes = 0;
}

TSPProblem::~TSPProblem(){
	this->best_path.clear();
}

void TSPProblem::run(){
	long current_solution_value;
	pair<int,int> separation_edge;
	
	
	while(!this->node_stack.empty()){
		this->visitedNodes++;
		TSPNode* current_node = this->node_stack.top();
		this->node_stack.pop();
		current_solution_value = current_node->eval();
		//Comparaison (minimisation)
		if (this->upper_bound > current_solution_value){
			if(current_node->isLeaf()){
				this->upper_bound = current_solution_value;
				this->best_path = current_node->getSelectedEdges();
			} else {
				//Choix arc
				separation_edge = current_node->separateEdgeChoice();
				//Création des fils
				createNodeForbidden(current_node, separation_edge);
				createNodeAllowed(current_node, separation_edge);
			}
		} else {
			this->cutedNodes++;
		}
		delete current_node;
	}
}

void TSPProblem::createNodeAllowed(TSPNode* father, pair<int,int> separate_edge){
	TSPNode* child = new TSPNode(*father);
	child->addSelectedEdge(separate_edge);
	this->node_stack.push(child);
}

void TSPProblem::createNodeForbidden(TSPNode* father, pair<int,int> separate_edge){
	TSPNode* child = new TSPNode(*father);
	child->addForbiddenEdge(separate_edge);
	this->node_stack.push(child);
}

long TSPProblem::getBestSolution(){
	return this->upper_bound;
}

void TSPProblem::printSolution(){
	deque<int> tour;
	tour.push_back(this->best_path.front().first);
	tour.push_back(this->best_path.front().second);
	bool found_edge = true;
	int size_tour = 2;
	while (size_tour < this->size && found_edge) {
		found_edge = false;
		for(vector< pair<int,int> >::iterator it = this->best_path.begin(); it != this->best_path.end(); it++){
			if ((*it).second == tour.front()) {
				tour.push_front((*it).first);
				size_tour++;
				found_edge = true;
				break;
			}
			else if ((*it).first == tour.back()) {
				tour.push_back((*it).second);
				size_tour++;
				found_edge = true;
				break;
			}
		}
	}
	cout << "Chemin : (";
	for(deque<int>::iterator it = tour.begin(); it != tour.end(); it++){
		cout << (*it) << " --> ";
	}
	cout << tour.front() << ")" << endl;
	cout << "Nombre de noeuds visites : " << this->visitedNodes << endl;
	cout << "Nombre de branches coupees : " << this->cutedNodes << endl;
}
