/*
 * TSPNode.h
 *
 *  Created on: 29 janv. 2015
 *      Author: kbarreau gmarques
 */

#ifndef TSPNODE_H_
#define TSPNODE_H_

#include <iostream>
#include <iomanip>
#include <algorithm>
#include <limits>
#include <cmath>
#include <utility>
#include <vector>
#include <deque>

using namespace std;

class TSPNode{
private :

	/* matrice de distances*/
	long ** matrix;
	/* taille de la matrice (size * size) */
	unsigned int size;
	/* tableau d'arcs selectionnes*/
	vector< pair<int,int> > selected_edges;
	/* borne inferieure */
	long lower_bound;
	
public :

	TSPNode(long ** matrix, int size, vector< pair<int,int> > selected_edges, long lower_bound);
	TSPNode(const TSPNode& node);
	~TSPNode();
	long ** getMatrix();
	int getSize() const;
	long getVal(int i, int j) const;
	vector< pair<int,int> > getSelectedEdges() const;
	void preprocessLowerBound();
	void addSelectedEdge(pair<int,int> edge);
	void addForbiddenEdge(pair<int,int> edge);
	pair<int,int> separateEdgeChoice();
	bool isLeaf();
	long eval();
	void printMatrix();
};
#endif
