#include "TSPData.h"

using namespace std;


TSPData::TSPData(fstream & in){

	string s;

	size=-1; // plus facile à débuger si bug lecture

	getline(in,s); // ligne de blabla (lp~ NAME)
	getline(in,s); // ligne de blabla (COMMENT)
	getline(in,s); // ligne de blabla (TYPE)

	in >> s; // blabla (DIMENSION:)

	in >> size; // lecture de la taille (valeur)

	matrix = new long* [size];
	for (int i = 0; i < size; i++) {
		matrix[i] = new long[size];
	}

	getline(in,s); // blabla (DIMENSION)
	getline(in,s); // blabla (EDGE_WEIGHT_TYPE)
	getline(in,s); // blabla (NODE_COORD_SECTION)

	double * x = new double[size]; // lecture des coordonnees
	double * y = new double[size];
	for (int i = 0; i < size; i++) {
		in >> s; // numero de ligne
		in >> x[i];
		in >> y[i];
	}

	for (int i = 0; i < size; ++i) { // calcul des distances
		for (int j = 0; j < size; ++j) {
			if (i == j) {
				matrix[i][j] = numeric_limits<long>::max();
			} else {
				matrix[i][j] = (long)floor(sqrt((x[i] - x[j]) * (x[i] - x[j])
						+ (y[i] - y[j]) * (y[i] - y[j]))+0.5);
			}
		}
	}

	delete[] y;
	delete[] x;
}

TSPData::~TSPData(){
	for(int i=0;i<size;++i){
		delete[] matrix[i];
	}
	delete[] matrix;
}

void TSPData::printMatrix(){
	for (int i = 0; i < size; ++i) { // calcul des distances
		for (int j = 0; j < size; ++j) {
			if( matrix[i][j] == numeric_limits<long>::max()){
				cout << setw(4) << " inf | ";
			} else {
				cout << setw(4) << matrix[i][j] << " | ";
			}
		}
		cout << endl;
	}
}


/* retourne la matrice de doubles */
long ** TSPData::getMatrix(){
	return matrix;
}

/* retourne la taille du probleme lu */
int TSPData::getSize() const {
	return size;
}
