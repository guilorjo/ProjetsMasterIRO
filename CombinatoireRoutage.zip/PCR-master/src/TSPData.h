/*
 * TSPData.h
 *
 *  Created on: 22 janv. 2015
 *      Author: fclautiaux
 */

#ifndef TSPDATA_H_
#define TSPDATA_H_

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <limits>

using namespace std;

class TSPData{
private :

	/* matrice de distances*/
	long ** matrix;
	/* taille de la matrice (size * size) */
	int size;

public :

	TSPData(fstream & in);
	~TSPData();
	long ** getMatrix();
	int getSize() const;
	void printMatrix();

};
#endif
