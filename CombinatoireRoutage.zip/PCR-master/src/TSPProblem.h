#ifndef _TSPPROBLEM_H_
#define _TSPPROBLEM_H_

#include <iostream>
#include <fstream>
#include <stack>
#include "TSPNode.h"
#include "TSPProblem.h"
#include "TSPData.h"

using namespace std;

class TSPProblem{
private:
	stack<TSPNode*> node_stack;
	vector< pair<int,int> > best_path;
	long upper_bound;
	int size;
	int visitedNodes;
	int cutedNodes;
	
	void createNodeAllowed(TSPNode* n, pair<int,int> edge);
	void createNodeForbidden(TSPNode* n, pair<int,int> edge);
		
public:
	TSPProblem(TSPData* data);
	~TSPProblem();
	void run();
	long getBestSolution();
	void printSolution();
};

#endif
