//============================================================================
// Name        : TSP.cpp
// Author      : F.C. & K.B. & G.M.
// Version     :
// Copyright   : Free for all
//============================================================================

#include <iostream>
#include <fstream>
#include "TSPData.h"
#include "TSPProblem.h"

using namespace std;

int main(int argc, char * argv[]) {

	fstream problem_file(argv[1], fstream::in);

	TSPData data(problem_file);
	TSPProblem solver(&data);

	solver.run();
	cout << "Best solution : " << solver.getBestSolution() << endl;
	solver.printSolution();
	
	data.printMatrix();
	
	problem_file.close();

	return 0;
}
