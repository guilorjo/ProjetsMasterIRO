#include "OAData.h"
OAData::OAData(int _nbScenarios,int _nbOrders,double _loadFactor,int _rgBenef,int _rgOS, int _meanP,int _rgP) :
	nbScenarios(_nbScenarios),nbOrders(_nbOrders)
{
	double totalP=0;
	for (int i=0;i<nbOrders;i++)
	{
		Order *po=new Order(nbScenarios,i,_rgBenef,_rgOS,_meanP,_rgP);
		orders.push_back(po);
		totalP+=po->meanDuration();
	}
	capacity=(int) (totalP*_loadFactor);
}

OAData::OAData(std::string file){
	std::ifstream istream;
	istream.open(file.c_str(), std::ios::in);

	std::vector<int> line;
	std::regex l("[[:digit:]]+");
	std::smatch m;
	std::string data;

	std::getline(istream, data);
	while(std::regex_search(data,m,l)){
		std::string d = m[0];
		line.push_back(atoi(d.c_str()));
		data = m.suffix().str();
	}

	this->nbScenarios = line[1];
	this->nbOrders = line[0];
	this->capacity = line[2];
	line.clear();

	int nblines = 0;
	while(nblines < nbOrders){
		std::getline(istream, data);
		while(std::regex_search(data,m,l)){
			std::string d = m[0];
			
			line.push_back(atoi(d.c_str()));
    		data = m.suffix().str();
		}
		Order *po=new Order(line[0], line[1], line[2]);
		orders.push_back(po);

		line.clear();
		std::getline(istream, data);
		while(std::regex_search(data,m,l)){
			std::string d = m[0];
			po->duration.push_back(atoi(d.c_str()));
    		data = m.suffix().str();
		}
		nblines++;
	}
}


OAData::~OAData(void)
{
	for (auto p : orders)
		delete p;
}

std::ostream &operator<<(std::ostream &os, const OAData& o)
{
	os << o.nbOrders << " " << o.nbScenarios << " " << o.capacity << std::endl;
	for (auto po : o.orders)
	{
		os << *po;
	}
	return os;
}