#pragma once

#include <vector>
#include <fstream>
#include <numeric>

class Order
{
public:
	Order(int nbScen,int _id,int _benefit,int _outsourcingCost,int _avgDuration,int _rgDuration);
	Order(int id, int benef, int outSource);
	~Order(void);

	int id;
	int benefit;
	int outSourcingCost;
	std::vector<int> duration;

	double meanDuration();

private:
	friend std::ostream &operator<<(std::ostream &os, const Order& o);
};