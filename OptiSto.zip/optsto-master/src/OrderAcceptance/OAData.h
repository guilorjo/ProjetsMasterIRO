#pragma once

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <regex>
#include <iterator>

#include "Order.h"
class OAData
{
public:

	int nbScenarios;
	int nbOrders;
	int capacity;

	OAData(int _nbScenarios,int _nbOrders,double _loadFactor,int _rgBenef,int _rgOS, int _meanP,int _rgP);
	OAData(std::string file);
	~OAData(void);

	std::vector<Order*> orders;

private:
	friend std::ostream &operator<<(std::ostream &os, const OAData& o);
};