#include "Order.h"

Order::Order(int nbScen,int _id,int _rgBenefit,int _rgOutsourcingCost,int _avgDuration,int _rgDuration) :
	id(_id)
{
	benefit=1+rand()%_rgBenefit;
	outSourcingCost=1+rand()%_rgOutsourcingCost;
	for (int s=0;s<nbScen;s++)
	{
		int p=std::max(1,_avgDuration-_rgDuration/2 + rand()%_rgDuration);
		duration.push_back(p);
	}
}

Order::Order(int id, int benef, int outSource){
	this->id = id;
	this->benefit = benef;
	this->outSourcingCost = outSource;
}

Order::~Order(void)
{
}

double Order::meanDuration()
{
	double p=std::accumulate(duration.begin(),duration.end(),0);
	return p/duration.size();
}

std::ostream &operator<<(std::ostream &os, const Order& o)
{
	os << o.id << " " << o.benefit << " " << o.outSourcingCost << std::endl;
	for (int p : o.duration)
	{
		os << p << " ";
	}
	os << std::endl;
	return os;
}