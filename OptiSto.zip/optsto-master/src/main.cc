#include <iostream>
#include <iostream>
#include <cstdlib>
#include <chrono>
#include "solvers/Solver.h"
#include "solvers/LShapedSolver.h"
#include "solvers/IntegerLShapedSolver.h"
#include "solvers/ExtendLShapedSolver.h"
#include "OrderAcceptance/OAData.h"

int main(int argc, char** argv){

	if(argc != 3){
		std::cout << "Utilisation :" << std::endl
				  << "\t" << argv[0] << " <instance> <modele>" << std::endl
				  << std::endl
				  << "\t Avec :" << std::endl
				  << "\t\t <instance Le numéro de l'instance" << std::endl
				  << "\t\t <modele> Le modèle (de 1 à 3)" << std::endl;
		return EXIT_FAILURE;
	}

	//OAData* instance = new OAData(4,5,0.5,10,10,10,5);

	std::string filename(argv[1]);
	int methode =  atoi(argv[2]);

	OAData* instance = new OAData(filename);

	//std::cout << *instance << std::endl;


	switch(methode){
		case 1:
			{
				std::cout << "Modèle 1 : l-shaped" << std::endl;
				LShapedSolver s(instance);
				auto start = std::chrono::steady_clock::now();
				s.solve();
				auto end = std::chrono::steady_clock::now();
				std::chrono::duration<double, std::milli> diff = end - start;
				std::cout << "Duration " << diff.count() << " ms." << std::endl;
				break;
			}
		case 2:
			{
				std::cout << "Modèle 2 : integer l-shaped" << std::endl;
				LShapedSolver l(instance);
				IntegerLShapedSolver s(instance);
				auto start = std::chrono::steady_clock::now();
				s.solve(l.solve());
				auto end = std::chrono::steady_clock::now();
				std::chrono::duration<double, std::milli> diff = end - start;
				std::cout << "Duration " << diff.count() << " ms." << std::endl;
				break;
			}
		case 3:
			{
				std::cout << "Modèle 3 : extend l-shaped" << std::endl;
				ExtendLShapedSolver s(instance);
				auto start = std::chrono::steady_clock::now();
				s.solve();
				auto end = std::chrono::steady_clock::now();
				std::chrono::duration<double, std::milli> diff = end - start;
				std::cout << "Duration " << diff.count() << " ms." << std::endl;
				break;
			}
		default:
			std::cout << "Erreur ! modele entre 1 et 3 " << std::endl;
	}

	delete instance;

	return EXIT_SUCCESS;
}
