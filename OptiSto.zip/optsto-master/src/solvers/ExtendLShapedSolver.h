#ifndef _EXTENDLSHAPEDSOLVER_H_
#define _EXTENDLSHAPEDSOLVER_H_

#include <iostream>
#include <cstdlib>
#include <iomanip>
#include "Solver.h"
#include "ilconcert/iloenv.h"
#include "ilconcert/ilomodel.h"
#include "ilcplex/ilocplexi.h"
#include "ilcplex/ilocplex.h"
#include "ilconcert/ilosys.h"
#include "ilconcert/iloexpression.h"
#include "../OrderAcceptance/OAData.h"

class ExtendLShapedSolver {
private:
	IloEnv* masterEnv;
	
	IloModel* master;

	OAData* problem;
public:
	ExtendLShapedSolver(OAData* problem);
	~ExtendLShapedSolver();
	bool worker(IloNum* x_, IloNumArray& pi, IloNumArray& sigma, double& obj);
	void solve();
};
#endif