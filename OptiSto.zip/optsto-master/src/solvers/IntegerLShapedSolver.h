#ifndef _INTEGERLSHAPEDSOLVER_H_
#define _INTEGERLSHAPEDSOLVER_H_

#include <iostream>
#include <cstdlib>
#include <algorithm>
#include "Solver.h"
#include <iomanip>
#include "ilconcert/iloenv.h"
#include "ilconcert/ilomodel.h"
#include "ilcplex/ilocplexi.h"
#include "ilcplex/ilocplex.h"
#include "ilconcert/ilosys.h"
#include "ilconcert/iloexpression.h"
#include "../OrderAcceptance/OAData.h"

class IntegerLShapedSolver {
private:
	IloEnv* masterEnv;
	IloEnv* workerEnv;
	
	IloModel* master;

	OAData* problem;
public:
	IntegerLShapedSolver(OAData* problem);
	~IntegerLShapedSolver();
	void buildMaster(IloNumVarArray& x, IloNumVar& theta);
	bool worker(IloNum* x_, double& obj);
	void solve(IloInt theta_d);
};
#endif