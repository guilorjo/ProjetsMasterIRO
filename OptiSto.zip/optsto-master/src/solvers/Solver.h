#ifndef _SOLVER_H_
#define _SOLVER_H_

#include <algorithm>
#include <climits>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include "ilconcert/iloenv.h"
#include "ilconcert/ilomodel.h"
#include "ilcplex/ilocplexi.h"
#include "ilconcert/ilosys.h"
#include "ilconcert/iloexpression.h"
#include "../OrderAcceptance/OAData.h"

class Solver {
protected:
	/*IloEnv* masterEnv;
	IloEnv* workerEnv;
	IloModel* model;
	OAData* problem;*/

public:
	Solver(OAData* problem);
	virtual ~Solver();
	virtual void initModel() = 0;
	void solve();
};

std::string n1(std::string label, IloInt i);
std::string n2(std::string label, IloInt i, IloInt j);
#endif