#include "IntegerLShapedSolver.h"

IntegerLShapedSolver::IntegerLShapedSolver(OAData* problem){
	this->problem = problem;
}

IntegerLShapedSolver::~IntegerLShapedSolver(){
}

void IntegerLShapedSolver::buildMaster(IloNumVarArray& x, IloNumVar& theta){

	IloInt nbOrders = this->problem->nbOrders;

	// INITIALISATION DES VARIABLES
	// -----------------------------
	// x_c = 1 ssi on accepte la commande c
	for(IloInt c=0; c<nbOrders; c++){
		x[c] = IloNumVar(*this->masterEnv, 0, 1, ILOBOOL, n1("x", c).c_str());
	}

	// FONCTION OBJECTIF
	// ----------------------------
	IloExpr objectif(*this->masterEnv);
	for(IloInt c=0; c<nbOrders; c++){
		objectif += (this->problem->orders[c]->benefit - this->problem->orders[c]->outSourcingCost)*x[c];
	}
	this->master->add(IloMaximize(*this->masterEnv, objectif + theta));
}

bool IntegerLShapedSolver::worker(IloNum* x_, double& obj){
	
	IloModel worker(*workerEnv);

	//Constantes
	IloInt nbOrders = this->problem->nbOrders;
	IloInt nbScenarios = this->problem->nbScenarios;
	IloInt capacity = this->problem->capacity;

	// INITIALISATION DES VARIABLES
	// ----------------------------
	IloArray< IloNumVarArray > y(*workerEnv, nbScenarios);
	for(IloInt s = 0; s < nbScenarios; s++){
		y[s] = IloNumVarArray(*workerEnv, nbOrders);
		for(IloInt c = 0; c < nbOrders; c++){
			y[s][c] = IloNumVar(*workerEnv, 0, 1, ILOBOOL, n2("y",s,c).c_str()); //relaxation linéaire
		}
	}

	// FONCTION OBJECTIF
	// ----------------------------
	IloExpr objectif(*workerEnv);
	for(IloInt s = 0; s < nbScenarios; s++){
		for(IloInt c = 0; c < nbOrders; c++){
			objectif += (1.0/nbScenarios)*y[s][c]*this->problem->orders[c]->outSourcingCost;
		}
	}
	worker.add(IloMaximize(*workerEnv, objectif));

	// CONTRAINTES
	// ----------------------------
	IloRangeArray worker_cst_knp(*workerEnv);
	//C1 : Sac-à-dos
	for(IloInt s = 0; s < nbScenarios; s++){
		IloExpr knp(*workerEnv);
		for(IloInt c = 0; c < nbOrders; c++){
			knp += this->problem->orders[c]->duration[s]*y[s][c];
		}
		worker_cst_knp.add(IloRange(*workerEnv, -IloInfinity, knp, capacity, n1("knp",s).c_str()));
	}

	IloRangeArray worker_cst_f(*workerEnv);
	//C2 : y=0 si x=0
	for(IloInt s = 0; s < nbScenarios; s++){
		for(IloInt c = 0; c < nbOrders; c++){
			worker_cst_f.add(IloRange(*workerEnv, 0, y[s][c], x_[c], n2("f",s,c).c_str()));
		}
	}
	worker.add(worker_cst_knp);
	worker.add(worker_cst_f);

	IloCplex workerCplex(worker);
	workerCplex.setOut(workerEnv->getNullStream());
	workerCplex.solve();
	//workerCplex.exportModel("worker.lp");

	obj = workerCplex.getObjValue();
	return workerCplex.getStatus() == IloAlgorithm::Optimal;
}

void IntegerLShapedSolver::solve(IloInt theta_d){

	double f_obj;

	IloInt nbOrders = this->problem->nbOrders;
	IloInt nbScenarios = this->problem->nbScenarios;
	IloInt capacity = this->problem->capacity;

	// MASTER PROBLEM
	this->masterEnv = new IloEnv();
	this->master = new IloModel(*this->masterEnv);

	IloNumVarArray x(*this->masterEnv, nbOrders);
	IloNumVar theta(*this->masterEnv, 0, 100000, ILOINT, "t");
	this->buildMaster(x,theta);

	int nb_cuts = 0;
	int MAX_cuts = 100000;
	double L = theta_d;

	while( nb_cuts < MAX_cuts ){  //TODO
		this->workerEnv = new IloEnv();

		IloCplex masterCplex(*this->master);
		masterCplex.setOut(masterEnv->getNullStream());
		masterCplex.solve();
		//masterCplex.exportModel("master.lp");

		if( masterCplex.getStatus() == IloAlgorithm::Optimal ){
			f_obj = masterCplex.getObjValue();

			//Résolution du problème maître
			IloNum x_[nbOrders]; 
			IloNum theta_;
			//std::cout << "THETA " << theta_ << std::endl;
			//Stockage de la solution
			theta_ = masterCplex.getValue(theta);
			for(IloInt c=0; c < nbOrders; c++){
				//x_[c] = masterCplex.getValue(x[c]);
				try{
					x_[c] = masterCplex.getValue(x[c]);
				}catch(IloAlgorithm::NotExtractedException e){}
			}
			//Résolution du sous-problème
			double q_s;

			if(this->worker(x_, q_s)){

				L = std::max(q_s, L);

				IloExpr coupe_ng(*this->masterEnv);
				int cardinal = 0;
				for(IloInt c = 0; c < nbOrders; c++){
					if( x_[c] == 1 ){
						coupe_ng += x[c]*(q_s - L);
						cardinal++;
					} else {
						coupe_ng -= x[c]*(q_s - L);
					}
				}
					
				//Ajoute-t-on une coupe ?
				if(theta_ > q_s){
					coupe_ng -= (q_s - L)*(cardinal-1);
					coupe_ng += L;
					this->master->add(IloRange(*this->masterEnv, -IloInfinity, theta-coupe_ng, 0, n1("ng", nb_cuts).c_str()));
				} else { //NON
					std::cout << "Résolu à l'optimal" << std::endl;
					std::cout << "Master value = " << f_obj << std::endl;
					return;
				}
			} else {
				std::cout << "end worker" << std::endl;
			}
		} else {
			std::cout << "end master" << std::endl;
			return;
		}
		nb_cuts++;
		this->workerEnv->end();
		delete this->workerEnv;
	}
	this->masterEnv->end();
}