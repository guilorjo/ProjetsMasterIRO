#ifndef _LSHAPEDSOLVER_H_
#define _LSHAPEDSOLVER_H_

#include <iostream>
#include <cstdlib>
#include <iomanip>
#include "Solver.h"
#include "ilconcert/iloenv.h"
#include "ilconcert/ilomodel.h"
#include "ilcplex/ilocplexi.h"
#include "ilcplex/ilocplex.h"
#include "ilconcert/ilosys.h"
#include "ilconcert/iloexpression.h"
#include "../OrderAcceptance/OAData.h"

class LShapedSolver {
private:
	IloEnv* masterEnv;
	IloEnv* workerEnv;
	
	IloModel* master;

	OAData* problem;
public:
	LShapedSolver(OAData* problem);
	~LShapedSolver();
	void buildMaster(IloNumVarArray& x, IloNumVar& theta);
	bool worker(IloNum* x_, IloNumArray& pi, IloNumArray& sigma, double& obj, double& dobj);
	IloInt solve();
};
#endif