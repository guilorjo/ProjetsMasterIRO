#include "Solver.h"

std::string n1(std::string label, IloInt i){
	std::stringstream name;
	name << label << "_" << i;
	return name.str();
}

std::string n2(std::string label, IloInt i, IloInt j){
	std::stringstream name;
	name << label << "_" << i << "_" << j;
	return name.str();
}


Solver::Solver(OAData* problem){
	/*this->environment = new IloEnv();
	this->model = new IloModel(*this->environment);
	this->problem = problem;*/
}

Solver::~Solver(){
	//this->environment->end();
}

void Solver::solve(){
	/*IloCplex cplex(*this->model);

	//cplex.setParam(IloCplex::MIPInterval, 1000);
	//cplex.setParam(IloCplex::MIPSearch, IloCplex::Traditional);
	cplex.solve();
	//cplex.exportModel("solver.lp");
	//cplex.exportModel("solver.sav");

	IloAlgorithm::Status algo_status = cplex.getStatus();
	if( algo_status != IloAlgorithm::Optimal ){
		this->environment->out() << "Il y a un problème" << std::endl;
	} else {
		this->environment->out() << "Le modèle a été résolu à l'optimal" << std::endl;
		this->environment->out() << "obj.value:  "<< cplex.getObjValue() << std::endl;
	}*/
}