# optsto
Projet optimisation stochastique
