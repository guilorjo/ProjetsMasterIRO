//============================================================================
// Name        : yolo.cpp
// Author      : YOLO
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <ilcplex/ilocplex.h>
#include <vector>
#include <string>
#include <sstream>
#include <cmath>

using namespace std;


// Le compilateur sépare vector<pair<..,..>> en 2 arguments a cause de la virgule dans les args de la macro...
struct Pair {
	IloExpr expr;
	int constraint;
	Pair(IloExpr e, int i){
		this->expr = e;
		this->constraint = i;
	}
};

struct Graph {
	int vertexCount;
	int edgeCount;
	int** adjacencyMatrix;
	Graph(int vertexCount) {
		this->vertexCount = vertexCount;
		this->edgeCount = 0;
		adjacencyMatrix = new int*[vertexCount];
		for (int i = 0; i < vertexCount; i++) {
			adjacencyMatrix[i] = new int[vertexCount];
			for (int j = 0; j < vertexCount; j++)
				adjacencyMatrix[i][j] = -1;
		}
	}
	int getSize(){
		return this->vertexCount;
	}
	void addEdge(int i, int j) {
		if (i >= 0 && i < vertexCount && j >= 0 && j < vertexCount) {
			int edgeN = edgeCount++;
			adjacencyMatrix[i][j] = edgeN;
			adjacencyMatrix[j][i] = edgeN;
		}
	}
	void removeEdge(int i, int j) {
		if (i >= 0 && i < vertexCount && j >= 0 && j < vertexCount) {
			adjacencyMatrix[i][j] = -1;
			adjacencyMatrix[j][i] = -1;
		}
	}
	bool isEdge(int i, int j) {
		if (i >= 0 && i < vertexCount && j >= 0 && j < vertexCount)
			return adjacencyMatrix[i][j] != -1;
		else
			return false;
	}
	int getEdge(int i, int j) {
		if (i >= 0 && i < vertexCount && j >= 0 && j < vertexCount)
			return adjacencyMatrix[i][j];
		else
			return -1;
	}
	~Graph() {
		for (int i = 0; i < vertexCount; i++)
			delete[] adjacencyMatrix[i];
		delete[] adjacencyMatrix;
	}
};

/* Also, an instance of IloCplex takes account of only one instance of a particular callback at any given time.
 * That is, if you call IloCplex::use more than once with the same class of callback, the last call overrides any previous one.
 * http://www.cs.cornell.edu/w8/iisi/ilog/cplex101/refcppcplex/html/classes/IloCplex_CallbackI.html
 */
// ILOUSERCUTCALLBACKI (nomCallback, type1, nom1, ..., typeI,nomI)
ILOUSERCUTCALLBACK6(AllCut, IloExpr, obj, IloNum, sizeGraph, IloExprArray, sumNeighbors, IloNum, capacity, IloNum, eps, vector<Pair>, bipartitions) {
	// cut 1 : utile sur de grandes capacités
	if (getValue(obj) < sizeGraph-1 - eps) {
		IloRange cut;
		try {
			cout << "cut obj " << getValue(obj) << endl;
			cut = (obj >= sizeGraph-1);
			addLocal(cut).end();
		} catch (IloException& e) {
			cut.end();
			throw;
		}
	}
	// cut 2 : n'est jamais utilisé (jamais violé)
	for (int i = 0; i < sizeGraph; i++) {
		cout << "tt: " << getValue(sumNeighbors[i]) << endl;
		if (getValue(sumNeighbors[i]) < (2*(sizeGraph-1)/capacity)-eps) {
			IloRange cut;
			try {
				cout << "cut neighbor" << endl;
				cut = (sumNeighbors[i] >= (2*(sizeGraph-1)/capacity));
				add(cut).end();
			} catch (IloException& e) {
				cut.end();
				throw;
			}
		}
	}


	// cut 3 : sumSurCoupeMin >= |s| * |s barre| * 2 (donner et recevoir)
	//Pour chaque biparti
				// check difference pair droite - getValue(pair gauche)
				// prendre la plus grande difference et ajouter pair gauche <= pair droit en cut
	vector<Pair>::iterator elem_max;
	int max_diff = 0;
	for (vector<Pair>::iterator it = bipartitions.begin() ; it != bipartitions.end(); ++it){
		int tmp =   it->constraint - getValue(it->expr);
		if(max_diff < tmp){
			elem_max = it;
			max_diff = tmp;
		}
	}
	bipartitions.erase(elem_max);
	if(elem_max->constraint > 0){
		IloRange cut;
		try{
			cout << "cut contrainte " <<  endl;
			cut = (elem_max->expr >= elem_max->constraint/capacity);
			add(cut).end();
		} catch (IloException& e){
			cut.end();
			throw;
		}
	}

}
// fonction utilisateur qui prépare les arguments pour la macro
//void makeArguments(const IloNumVarArray vars, IloExprArray lhs, IloNumArray rhs) {
//	lhs.add(vars[0] - vars[1]);
//	rhs.add(0.0);
//	lhs.add(vars[1] - vars[2]);
//	rhs.add(0.0);
//}
int main(int argc, char** argv) {
	IloEnv env;
	Graph g(15);
	g.addEdge(0,8);
	g.addEdge(0,9);
	g.addEdge(1,6);
	g.addEdge(1,7);
	g.addEdge(1,8);
	g.addEdge(2,3);
	g.addEdge(2,5);
	g.addEdge(2,6);
	g.addEdge(3,5);
	g.addEdge(3,8);
	g.addEdge(4,5);
	g.addEdge(4,6);
	g.addEdge(6,13);
	g.addEdge(7,10);
	g.addEdge(7,14);
	g.addEdge(8,9);
	g.addEdge(9,10);
	g.addEdge(9,12);
	g.addEdge(10,12);
	g.addEdge(11,13);
	g.addEdge(11,14);
	g.addEdge(13,14);
	try {
		IloModel m(env);
		IloIntVarArray x(env, g.edgeCount );
		vector<vector <IloNumVarArray> > y,yy;

		// Création du modèle
		for(IloInt e=0; e< g.edgeCount ;e++)
		{
			stringstream name;
			name << "x_" << e ;
			x[e] = IloIntVar(env,0, 10000000, name.str().c_str());
		}
		for(IloInt s=0;s<g.edgeCount;s++)
		{
			vector<IloNumVarArray > pg;
			vector<IloNumVarArray > gp;
			for(IloInt t=0; t<g.edgeCount; t++)
			{
				IloNumVarArray z(env, g.edgeCount);
				IloNumVarArray zz(env, g.edgeCount);
				for(IloInt e=0; e<g.edgeCount ; e++)
				{
					stringstream name;
					name << "y_" << s << "_" << t << "_" << e;
					z[e] = IloNumVar(env, 0, IloInfinity, name.str().c_str());
					stringstream name1;
					name1 << "yy_" << s << "_" << t << "_" << e;
					zz[e] = IloNumVar(env, 0, IloInfinity, name1.str().c_str());
				}
				pg.push_back(z);
				gp.push_back(zz);
			}
			y.push_back(pg);
			yy.push_back(gp);
		}
		IloInt C=2;
		for (int e=0; e<g.edgeCount; e++) {
			IloExpr myExpr(env);
			for(int s=0; s<g.vertexCount; s++) {
				for(int t=0; t<g.vertexCount; t++) {
					if(s!=t){
					myExpr += y[s][t][e]+yy[s][t][e];
					}
				}
			}
			myExpr -= C*x[e];
			m.add(myExpr<=0);
		}
		for(int s=0;s<g.vertexCount;s++){
			for(int t=0;t<g.vertexCount;t++){
				for(int k=0; k<g.vertexCount;k++){
					IloExpr Expr(env);

					for(int i=0;i<g.vertexCount;i++) {
						if(g.isEdge(k,i) && (s!=t)){
							int e = g.getEdge(i, k);
							if(i<k) {
								Expr -= y[s][t][e];
								Expr += yy[s][t][e];
							}
							else {
								Expr +=y[s][t][e];
								Expr -=yy[s][t][e];
							}
						}
					}
					if(s!=t){
						if(k==s){
							m.add(Expr==1);
						}
						else if(k==t){
							m.add(Expr==-1);
						}
						else {
							m.add(Expr==0);
						}
					}
					//myExpr.end();
				}
			}
		}
		IloExpr fct(env);
		for(int e=0; e<g.edgeCount; e++) {
			fct += x[e];
		}
		m.add(IloMinimize(env,fct));

		IloCplex cplex(m);

		IloExprArray sumNeighbors(env, g.vertexCount);
		for(int i = 0; i < g.vertexCount; i++) {
			IloExpr sumNeighbor(env);
			for (int j = 0; j < g.vertexCount; j++) {
				if (g.isEdge(i,j)) {
					sumNeighbor += x[g.getEdge(i,j)];
				}
			}
			sumNeighbors[i] = sumNeighbor;
		}

		vector<Pair> bipartitions;
		int compteur = 1;
		int nb_sommets = g.getSize();

		//sommet a dans partition 1 : bp_sommets[a] = false;
		//sommet a dans partition 2 : .. = true;
		bool* bipartition_sommets = new bool[nb_sommets];

		for(int i=0; i<nb_sommets; i++){
			bipartition_sommets[i] = false;
		}
		while(compteur < pow(2,nb_sommets-1)){
			IloExpr coupe(env);
			int s = 0;
			int i = 0;
			int dividende = compteur;
			while(dividende > 0 && i< nb_sommets){
				bipartition_sommets[i] = dividende % 2;
				s += bipartition_sommets[i];
				dividende /= 2;
				i++;
			}
			for(int i=0; i<nb_sommets-1; i++){
				for(int j=i+1; j<nb_sommets; j++){
					if(bipartition_sommets[i]!=bipartition_sommets[j]){
						if(g.isEdge(i,j)){
							coupe += x[g.getEdge(i,j)];
						}
					}
				}
			}

			bipartitions.push_back(Pair(coupe,s*(nb_sommets-s)*2));
			compteur++;
		}
		// pour blabla
			// toutes les coupes min de tous les bipartis avec leur |s| * |s barre| * 2 associé
			// coupe min : liens reliant |s| vers |s barre|

		cplex.use(AllCut(env, fct, g.vertexCount, sumNeighbors, C, cplex.getParam(IloCplex::EpRHS), bipartitions));

		cplex.setParam(IloCplex::MIPInterval, 1000);
		cplex.setParam(IloCplex::MIPSearch, IloCplex::Traditional);

		cplex.solve();
		//fct.end();
		//Appel du model
		IloAlgorithm::Status algStatus = cplex.getStatus();

		//cplex.exportModel("/net/cremi/kbarreau/model.lp");

		if (algStatus != IloAlgorithm::Optimal) {
			env.out() << "Il y a un probleme";
		}else {
			env.out() << "Le modele a ete resolu a l'optimal";
			env.out() << " obj.value:  "<< cplex.getObjValue();
		}
	} catch (IloException& ex) {
		cerr << "Error: " << ex << endl;
	}
	env.end();
	return 0;
}


